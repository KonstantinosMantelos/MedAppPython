"""Ωράριο ιατρείου για μία ημέρα της εβδομάδας."""
from dataclasses import dataclass
from datetime import datetime, time, timedelta


@dataclass(frozen=True)
class WorkingHours:
    doctor_amka: str
    day_of_week: int          # 1 = Δευτέρα ... 7 = Κυριακή (όπως date.isoweekday())
    start_time: time
    end_time: time
    slot_minutes: int

    def generate_slot_times(self) -> list[time]:
        """Οι ώρες έναρξης όλων των χρονοθυρίδων του ωραρίου."""
        day = datetime(2000, 1, 1)
        t = datetime.combine(day, self.start_time)
        end = datetime.combine(day, self.end_time)
        step = timedelta(minutes=self.slot_minutes)
        times = []
        while t + step <= end:
            times.append(t.time())
            t += step
        return times
