"""Διαθεσιμότητα ιατρού σε μία ημέρα (από τα 4 ραντεβού της), όπως εμφανίζεται στον ασθενή."""
from enum import Enum


class AvailabilityLevel(Enum):
    AVAILABLE = "Διαθεσιμότητα"          # 3–4 ελεύθερα ραντεβού (πράσινο)
    PARTIAL = "Μερική διαθεσιμότητα"     # 1–2 ελεύθερα ραντεβού (κίτρινο)
    NONE = "Μη διαθέσιμο"                # κανένα ελεύθερο ραντεβού (κόκκινο)

    @property
    def label(self) -> str:
        return self.value

    def __str__(self) -> str:
        return self.value
