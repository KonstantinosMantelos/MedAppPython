"""Ραντεβού ασθενή με ιατρό."""
from dataclasses import dataclass
from datetime import date, datetime, time

from medapp.model.appointment_status import AppointmentStatus
from medapp.model.doctor import Doctor


@dataclass
class Appointment:
    id: int
    patient_amka: str
    doctor: Doctor
    date: date
    time: time
    reason: str
    status: AppointmentStatus
    created_at: datetime

    @property
    def date_time(self) -> datetime:
        return datetime.combine(self.date, self.time)

    def cancel(self) -> None:
        """Ακύρωση: επιτρέπεται μόνο από την κατάσταση ACTIVE."""
        if self.status != AppointmentStatus.ACTIVE:
            raise ValueError("Μόνο ενεργό ραντεβού μπορεί να ακυρωθεί.")
        self.status = AppointmentStatus.CANCELLED

    def get_effective_status(self, now: datetime) -> AppointmentStatus:
        """Η κατάσταση όπως εμφανίζεται στον χρήστη τη στιγμή now."""
        if self.status == AppointmentStatus.ACTIVE and self.date_time <= now:
            return AppointmentStatus.COMPLETED
        return self.status

    def is_cancellable(self, now: datetime) -> bool:
        """Μπορεί να ακυρωθεί αν είναι ενεργό και δεν έχει ακόμη έρθει η ώρα του."""
        return self.get_effective_status(now) == AppointmentStatus.ACTIVE
