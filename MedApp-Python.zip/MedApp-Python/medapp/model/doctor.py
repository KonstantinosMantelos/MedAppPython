"""Ιατρός εγγεγραμμένος στην εφαρμογή."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Doctor:
    amka: str
    first_name: str
    last_name: str
    specialty: str
    phone: str
    email: str
    area: str
    address: str

    @property
    def full_name(self) -> str:
        return f"{self.last_name} {self.first_name}"

    @property
    def contact_info(self) -> str:
        """Στοιχεία επικοινωνίας σε μία γραμμή."""
        return f"{self.phone} · {self.email}"

    def __str__(self) -> str:
        return f"{self.full_name} ({self.specialty}, {self.area})"
