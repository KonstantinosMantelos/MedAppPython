"""Χρονοθυρίδα ιατρού (ημέρα + ώρα) και αν είναι ελεύθερη."""
from dataclasses import dataclass
from datetime import date, time


@dataclass(frozen=True)
class TimeSlot:
    date: date
    time: time
    available: bool

    def __str__(self) -> str:
        return self.time.strftime("%H:%M") + ("" if self.available else " (κλεισμένο)")
