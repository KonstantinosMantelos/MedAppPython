"""Κατάσταση ραντεβού.

Στη βάση αποθηκεύονται μόνο οι ACTIVE και CANCELLED· η COMPLETED προκύπτει
όταν ένα ενεργό ραντεβού έχει περάσει.
"""
from enum import Enum


class AppointmentStatus(Enum):
    ACTIVE = "Ενεργό"
    CANCELLED = "Ακυρωμένο"
    COMPLETED = "Ολοκληρωμένο"

    @property
    def label(self) -> str:
        return self.value

    def __str__(self) -> str:
        return self.value
