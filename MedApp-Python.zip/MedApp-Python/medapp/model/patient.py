"""Ασθενής-χρήστης. Ταυτοποιείται με τον ΑΜΚΑ του."""
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Patient:
    amka: str
    first_name: str
    last_name: str
    phone: str
    email: str
    password_hash: str
    salt: str
    created_at: datetime

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    def __str__(self) -> str:
        return f"{self.full_name} [{self.amka}]"
