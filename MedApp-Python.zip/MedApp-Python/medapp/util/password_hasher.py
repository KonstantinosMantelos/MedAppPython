"""Ασφαλής αποθήκευση κωδικών με PBKDF2 και τυχαίο salt (ο κωδικός δεν αποθηκεύεται ποτέ)."""
import base64
import hashlib
import hmac
import os


class PasswordHasher:
    ITERATIONS = 65_536

    @staticmethod
    def new_salt() -> str:
        return base64.b64encode(os.urandom(16)).decode("ascii")

    @staticmethod
    def hash(password: str, salt: str) -> str:
        key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), base64.b64decode(salt),
                                  PasswordHasher.ITERATIONS, dklen=32)
        return base64.b64encode(key).decode("ascii")

    @staticmethod
    def verify(password: str, salt: str, expected_hash: str) -> bool:
        return hmac.compare_digest(PasswordHasher.hash(password, salt), expected_hash)
