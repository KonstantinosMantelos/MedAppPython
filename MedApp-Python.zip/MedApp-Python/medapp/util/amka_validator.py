"""Έλεγχος εγκυρότητας ΑΜΚΑ: 11 ψηφία, τα 6 πρώτα είναι ημερομηνία (ΗΗΜΜΕΕ)
και το τελευταίο είναι ψηφίο ελέγχου κατά τον αλγόριθμο Luhn."""
import re


class AmkaValidator:
    @staticmethod
    def is_valid(amka: str | None) -> bool:
        if amka is None or not re.fullmatch(r"\d{11}", amka):
            return False
        day, month = int(amka[0:2]), int(amka[2:4])
        if not (1 <= day <= 31 and 1 <= month <= 12):
            return False
        return AmkaValidator.luhn(amka)

    @staticmethod
    def luhn(digits: str) -> bool:
        total = 0
        for i, ch in enumerate(reversed(digits)):
            d = int(ch)
            if i % 2 == 1:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
        return total % 10 == 0
