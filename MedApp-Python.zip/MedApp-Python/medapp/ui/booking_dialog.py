"""Διαθεσιμότητα ιατρού (ημέρες/ώρες) και κράτηση ραντεβού με λόγο επίσκεψης."""
import tkinter as tk
from datetime import date
from tkinter import messagebox, ttk

from medapp.model.doctor import Doctor
from medapp.model.patient import Patient
from medapp.model.time_slot import TimeSlot
from medapp.service.appointment_service import AppointmentService
from medapp.service.doctor_service import DoctorService
from medapp.ui import theme, ui_support
from medapp.ui.widgets import Card, ChipButton, FlatButton, label, logo
from medapp.util.date_utils import DateUtils

LEVEL_TAG = {"AVAILABLE": "green", "PARTIAL": "yellow", "NONE": "red"}


class BookingDialog(tk.Toplevel):
    def __init__(self, owner: tk.Misc, patient: Patient, doctor: Doctor, service: AppointmentService,
                 doctor_service: DoctorService, preferred_date: date | None = None):
        """Με preferred_date: ανοίγει κατευθείαν στην ημέρα που διάλεξε ο ασθενής στην αναζήτηση."""
        super().__init__(owner)
        self.patient = patient
        self.doctor = doctor
        self.service = service
        self.doctor_service = doctor_service
        self.preferred_date = preferred_date
        self.booked = False
        self.selected_slot: TimeSlot | None = None
        self.selected_reason: str | None = None
        self.slot_chips: list[ChipButton] = []
        self.reason_chips: list[ChipButton] = []
        self.title(f"Κράτηση ραντεβού – {doctor.full_name}")
        self.configure(bg=theme.BACKGROUND, padx=16, pady=14)
        self.geometry("900x680")
        self.transient(owner.winfo_toplevel())

        # στοιχεία ιατρού
        info = Card(self, padx=16, pady=12)
        info.pack(fill="x")
        logo(info, 44, theme.CARD).pack(side="left", padx=(0, 14))
        text = tk.Frame(info, bg=theme.CARD)
        text.pack(side="left")
        label(text, doctor.full_name, 15, True).pack(anchor="w")
        label(text, f"{doctor.specialty} · {doctor.address}, {doctor.area}", 10, fg=theme.MUTED).pack(anchor="w")
        label(text, doctor.contact_info, 10, fg=theme.MUTED).pack(anchor="w")

        buttons = tk.Frame(self, bg=theme.BACKGROUND)
        buttons.pack(side="bottom", fill="x", pady=(12, 0))
        FlatButton(buttons, "Κράτηση ραντεβού", FlatButton.PRIMARY, self.book).pack(side="right")
        FlatButton(buttons, "Κλείσιμο", FlatButton.SECONDARY, self.destroy).pack(side="right", padx=10)

        middle = tk.Frame(self, bg=theme.BACKGROUND)
        middle.pack(fill="both", expand=True, pady=(12, 0))
        days_card = Card(middle, padx=12, pady=12)
        days_card.pack(side="left", fill="y")
        label(days_card, "1. Ημέρα", 12, True).pack(anchor="w", pady=(0, 6))
        self.day_tree = ttk.Treeview(days_card, columns=("day", "free"), show="headings", selectmode="browse",
                                     height=12)
        self.day_tree.heading("day", text="Ημέρα", anchor="w")
        self.day_tree.heading("free", text="Ελεύθερες", anchor="w")
        self.day_tree.column("day", width=170, anchor="w")
        self.day_tree.column("free", width=100, anchor="w")
        theme.configure_row_tags(self.day_tree)
        day_scroll = ttk.Scrollbar(days_card, orient="vertical", command=self.day_tree.yview)
        self.day_tree.configure(yscrollcommand=day_scroll.set)
        self.day_tree.pack(side="left", fill="y")
        day_scroll.pack(side="left", fill="y")
        self.day_tree.bind("<<TreeviewSelect>>", lambda e: self.load_slots())

        right = Card(middle, padx=16, pady=12)
        right.pack(side="left", fill="both", expand=True, padx=(12, 0))
        self.slot_title = label(right, "2. Ώρα", 12, True)
        self.slot_title.pack(anchor="w")
        self.slot_grid = tk.Frame(right, bg=theme.CARD)
        self.slot_grid.pack(anchor="w", pady=(8, 0))

        # λόγος επίσκεψης: 3 έτοιμες επιλογές του ιατρού + «Άλλο» με ελεύθερο κείμενο
        reason_box = tk.Frame(right, bg=theme.CARD)
        reason_box.pack(side="bottom", fill="x")
        label(reason_box, "3. Λόγος επίσκεψης *", 12, True).pack(anchor="w", pady=(0, 6))
        options = tk.Frame(reason_box, bg=theme.CARD)
        options.pack(fill="x")
        ok, reasons = ui_support.run(self, lambda: doctor_service.get_visit_reasons(doctor))
        for i, reason in enumerate(reasons or []):
            chip = ChipButton(options, reason, size=10, pady=7)
            chip.command = lambda r=reason: self.select_reason(r)
            chip.grid(row=i // 2, column=i % 2, sticky="ew", padx=(0, 8), pady=(0, 8))
            self.reason_chips.append(chip)
        options.columnconfigure(0, weight=1, uniform="r")
        options.columnconfigure(1, weight=1, uniform="r")
        self.other_frame = tk.Frame(reason_box, bg=theme.CARD)
        label(self.other_frame, "Γράψτε τον λόγο της επίσκεψης", 10, True, fg=theme.MUTED).pack(anchor="w")
        self.reason_text = tk.Text(self.other_frame, height=3, wrap="word", font=theme.font(11), relief="flat",
                                   highlightthickness=1, highlightbackground=theme.BORDER,
                                   highlightcolor=theme.PRIMARY, padx=8, pady=6)
        self.reason_text.pack(fill="x", pady=(4, 0))

        self.load_days()

    def show(self) -> bool:
        """Ανοίγει το παράθυρο ως modal και επιστρέφει αν έγινε κράτηση."""
        self.wait_visibility()
        self.grab_set()
        self.wait_window()
        return self.booked

    # ---------- ημέρες και ώρες ----------

    def load_days(self) -> None:
        self.day_tree.delete(*self.day_tree.get_children())
        ok, overview = ui_support.run(self, lambda: self.service.get_availability_overview(
            self.doctor, AppointmentService.BOOKING_HORIZON_DAYS + 1))
        for day, free in (overview or {}).items():
            text = "πλήρες" if free == 0 else f"{free} ελεύθερ{'η' if free == 1 else 'ες'}"
            self.day_tree.insert("", "end", iid=day.isoformat(), values=(DateUtils.format_long(day), text),
                                 tags=(LEVEL_TAG[AppointmentService.classify(free).name],))
        children = self.day_tree.get_children()
        pick = None
        if self.preferred_date and self.preferred_date.isoformat() in children:
            pick = self.preferred_date.isoformat()
        elif overview:
            pick = next((d.isoformat() for d, free in overview.items() if free > 0), None)
        if pick:
            self.day_tree.selection_set(pick)
            self.day_tree.see(pick)
        self.load_slots()

    def selected_day(self) -> date | None:
        selection = self.day_tree.selection()
        return date.fromisoformat(selection[0]) if selection else None

    def load_slots(self) -> None:
        for chip in self.slot_chips:
            chip.destroy()
        for w in self.slot_grid.winfo_children():
            w.destroy()
        self.slot_chips = []
        self.selected_slot = None
        day = self.selected_day()
        if day is None:
            self.slot_title.configure(text="2. Ώρα")
            return
        self.slot_title.configure(text=f"2. Ώρα · {DateUtils.format_day_date(day)}")
        ok, slots = ui_support.run(self, lambda: self.service.get_available_slots(self.doctor, day))
        if not slots:
            label(self.slot_grid, "Δεν υπάρχουν ελεύθερες ώρες αυτή την ημέρα.", 11,
                  fg=theme.MUTED).grid(row=0, column=0, sticky="w")
            return
        for i, s in enumerate(slots):
            chip = ChipButton(self.slot_grid, DateUtils.format_time(s.time), padx=22, pady=7)
            chip.command = lambda c=chip, slot=s: self._select_slot(c, slot)
            chip.grid(row=i // 4, column=i % 4, padx=(0, 8), pady=(0, 8))
            self.slot_chips.append(chip)

    def _select_slot(self, chip: ChipButton, slot: TimeSlot) -> None:
        for c in self.slot_chips:
            c.set_selected(c is chip)
        self.selected_slot = slot

    def select_reason(self, reason: str) -> None:
        """Το πεδίο κειμένου εμφανίζεται μόνο όταν επιλεγεί «Άλλο»."""
        self.selected_reason = reason
        for c in self.reason_chips:
            c.set_selected(c.cget("text") == reason)
        if reason == DoctorService.OTHER_REASON:
            self.other_frame.pack(fill="x", pady=(2, 0))
            self.reason_text.focus_set()
        else:
            self.other_frame.pack_forget()

    # ---------- κράτηση ----------

    def book(self) -> None:
        slot = self.selected_slot
        if slot is None:
            messagebox.showinfo("MedApp", "Επιλέξτε ημέρα και ελεύθερη ώρα.", parent=self)
            return
        # πρώτα ο λόγος: αν λείπει, μένουν ως έχουν η ημέρα και η ώρα που διάλεξε ο ασθενής
        ok, reason = ui_support.run(self, lambda: self.doctor_service.resolve_reason(
            self.selected_reason, self.reason_text.get("1.0", "end")))
        if not ok or reason is None:
            return
        ok, _ = ui_support.run(self, lambda: self.service.book(self.patient, self.doctor, slot.date, slot.time,
                                                               reason))
        if ok:
            self.booked = True
            messagebox.showinfo("MedApp", f"Το ραντεβού κλείστηκε!\n{self.doctor.full_name}\n"
                                          f"{DateUtils.format_day_date(slot.date)} στις "
                                          f"{DateUtils.format_time(slot.time)}", parent=self)
            self.destroy()
        else:
            self.preferred_date = slot.date
            self.load_days()
