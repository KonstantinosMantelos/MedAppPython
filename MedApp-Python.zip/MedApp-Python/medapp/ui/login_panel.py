"""Οθόνη σύνδεσης ασθενή με ΑΜΚΑ και κωδικό."""
import tkinter as tk

from medapp.service.auth_service import AuthService
from medapp.ui import theme, ui_support
from medapp.ui.brand import split_screen
from medapp.ui.widgets import FlatButton, entry, label


class LoginPanel(tk.Frame):
    def __init__(self, parent: tk.Misc, frame, auth_service: AuthService):
        super().__init__(parent, bg=theme.BACKGROUND)
        self.frame = frame
        self.auth_service = auth_service
        root, form = split_screen(self, "Κλείστε ραντεβού με τον ιατρό σας γρήγορα, χωρίς τηλεφωνήματα.",
                                  ["Διαλέξτε ειδικότητα και περιοχή", "Δείτε τις ελεύθερες ώρες",
                                   "Κλείστε το ραντεβού σας"])
        root.pack(fill="both", expand=True)

        label(form, "Σύνδεση", 20, True).pack(anchor="w")
        label(form, "Μπείτε με τον ΑΜΚΑ και τον κωδικό σας", 11, fg=theme.MUTED).pack(anchor="w", pady=(2, 18))
        label(form, "ΑΜΚΑ", 10, True, fg=theme.MUTED).pack(anchor="w")
        self.amka_field = entry(form)
        self.amka_field.pack(fill="x", ipady=6, pady=(4, 12))
        label(form, "Κωδικός", 10, True, fg=theme.MUTED).pack(anchor="w")
        self.password_field = entry(form, show="•")
        self.password_field.pack(fill="x", ipady=6, pady=(4, 16))
        self.login_button = FlatButton(form, "Σύνδεση", FlatButton.PRIMARY, self.login, pady=9)
        self.login_button.pack(fill="x")
        FlatButton(form, "Δημιουργία λογαριασμού", FlatButton.SECONDARY, frame.show_register,
                   pady=9).pack(fill="x", pady=(10, 18))
        label(form, "Δοκιμαστικός λογαριασμός:\n01019000015 / demo123", 9, fg=theme.MUTED,
              justify="left").pack(anchor="w")
        self.amka_field.configure(width=32)

        self.amka_field.bind("<Return>", lambda e: self.password_field.focus_set())
        self.password_field.bind("<Return>", lambda e: self.login())

    def login(self) -> None:
        ok, patient = ui_support.run(self, lambda: self.auth_service.login(self.amka_field.get(),
                                                                           self.password_field.get()))
        if ok and patient is not None:
            self.frame.show_home(patient)

    def reset(self) -> None:
        self.amka_field.delete(0, "end")
        self.password_field.delete(0, "end")
        self.amka_field.focus_set()
