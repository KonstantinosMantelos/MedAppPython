"""Επαναχρησιμοποιούμενα στοιχεία: κάρτα, κουμπιά, «κουμπάκια» επιλογής, ετικέτες, λογότυπο."""
import tkinter as tk
from collections.abc import Callable

from medapp.ui import theme


class Card(tk.Frame):
    """Λευκή κάρτα με λεπτό περίγραμμα."""

    def __init__(self, parent: tk.Misc, padx: int = 22, pady: int = 18):
        super().__init__(parent, bg=theme.CARD, highlightthickness=1, highlightbackground=theme.BORDER,
                         padx=padx, pady=pady)


class FlatButton(tk.Label):
    """Επίπεδο κουμπί: PRIMARY (γεμάτο), SECONDARY (περίγραμμα), DANGER (κόκκινο), ON_DARK (πάνω σε μπλε)."""
    PRIMARY, SECONDARY, DANGER, ON_DARK = "primary", "secondary", "danger", "on_dark"

    _COLORS = {  # (φόντο, φόντο hover, κείμενο, περίγραμμα)
        PRIMARY: (theme.PRIMARY, theme.PRIMARY_DARK, "#FFFFFF", theme.PRIMARY),
        SECONDARY: (theme.CARD, theme.PRIMARY_LIGHT, theme.PRIMARY, theme.PRIMARY),
        DANGER: (theme.CARD, theme.DANGER_LIGHT, theme.DANGER, theme.DANGER),
        ON_DARK: (theme.ON_DARK, theme.ON_DARK_HOVER, "#FFFFFF", theme.ON_DARK),
    }

    def __init__(self, parent: tk.Misc, text: str, kind: str = PRIMARY,
                 command: Callable[[], None] | None = None, size: int = 11, padx: int = 16, pady: int = 7):
        self.kind = kind
        self.command = command
        self.enabled = True
        bg, _, fg, border = self._COLORS[kind]
        super().__init__(parent, text=text, bg=bg, fg=fg, font=theme.font(size, True), padx=padx, pady=pady,
                         cursor="hand2", highlightthickness=1, highlightbackground=border, highlightcolor=border)
        self.bind("<Enter>", lambda e: self._paint(hover=True))
        self.bind("<Leave>", lambda e: self._paint(hover=False))
        self.bind("<ButtonRelease-1>", self._click)

    def _click(self, _event: object = None) -> None:
        if self.enabled and self.command:
            self.command()

    def invoke(self) -> None:
        self._click()

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled
        self._paint(hover=False)

    def _paint(self, hover: bool) -> None:
        bg, bg_hover, fg, border = self._COLORS[self.kind]
        if not self.enabled:
            self.configure(bg=theme.NEUTRAL_LIGHT if self.kind == self.PRIMARY else bg, fg="#A0A7B2",
                           highlightbackground=theme.BORDER, cursor="arrow")
            return
        self.configure(bg=bg_hover if hover else bg, fg=fg, highlightbackground=border, cursor="hand2")


class ChipButton(tk.Label):
    """Επιλέξιμο «κουμπάκι» (περιοχή, ώρα, λόγος επίσκεψης, εβδομάδα/μήνας)."""

    def __init__(self, parent: tk.Misc, text: str, command: Callable[[], None] | None = None,
                 selected: bool = False, on_dark: bool = False, size: int = 11, padx: int = 14, pady: int = 6):
        self.command = command
        self.selected = selected
        self.on_dark = on_dark
        super().__init__(parent, text=text, font=theme.font(size, True), padx=padx, pady=pady, cursor="hand2",
                         highlightthickness=0 if on_dark else 1)
        self.bind("<Enter>", lambda e: self._paint(hover=True))
        self.bind("<Leave>", lambda e: self._paint(hover=False))
        self.bind("<ButtonRelease-1>", self._click)
        self._paint(hover=False)

    def _click(self, _event: object = None) -> None:
        if self.command:
            self.command()

    def invoke(self) -> None:
        self._click()

    def set_selected(self, selected: bool) -> None:
        self.selected = selected
        self._paint(hover=False)

    def _paint(self, hover: bool) -> None:
        if self.on_dark:
            if self.selected:
                self.configure(bg="#FFFFFF", fg=theme.PRIMARY_DARK)
            else:
                self.configure(bg=theme.ON_DARK if hover else theme.PRIMARY, fg="#FFFFFF")
        elif self.selected:
            self.configure(bg=theme.PRIMARY, fg="#FFFFFF", highlightbackground=theme.PRIMARY)
        else:
            self.configure(bg=theme.PRIMARY_LIGHT if hover else theme.CARD, fg=theme.PRIMARY,
                           highlightbackground=theme.CHIP_BORDER)


class Pill(tk.Label):
    """Μικρή χρωματιστή ετικέτα (π.χ. «3–4 ελεύθερα», «Ενεργό»)."""

    def __init__(self, parent: tk.Misc, text: str, fg: str, bg: str):
        super().__init__(parent, text=text, fg=fg, bg=bg, font=theme.font(9, True), padx=10, pady=2)


class LinkLabel(tk.Label):
    """Κείμενο-σύνδεσμος που εκτελεί μια ενέργεια."""

    def __init__(self, parent: tk.Misc, text: str, command: Callable[[], None], bg: str = theme.CARD):
        super().__init__(parent, text=text, fg=theme.PRIMARY, bg=bg, cursor="hand2",
                         font=(*theme.font(10), "underline"))
        self.bind("<ButtonRelease-1>", lambda e: command())


def label(parent: tk.Misc, text: str, size: int = 11, bold: bool = False, fg: str = theme.TEXT,
          bg: str = theme.CARD, **kw) -> tk.Label:
    return tk.Label(parent, text=text, font=theme.font(size, bold), fg=fg, bg=bg, **kw)


def entry(parent: tk.Misc, show: str | None = None) -> tk.Entry:
    e = tk.Entry(parent, font=theme.font(12), relief="flat", bg=theme.CARD, fg=theme.TEXT,
                 highlightthickness=1, highlightbackground=theme.BORDER, highlightcolor=theme.PRIMARY,
                 insertbackground=theme.TEXT)
    if show:
        e.configure(show=show)
    return e


def logo(parent: tk.Misc, size: int, bg: str) -> tk.Canvas:
    """Ιατρικός σταυρός μέσα σε λευκό κύκλο."""
    c = tk.Canvas(parent, width=size, height=size, bg=bg, highlightthickness=0)
    c.create_oval(1, 1, size - 1, size - 1, fill="#FFFFFF", outline="")
    arm, length = size // 5, size * 3 // 5
    o = (size - length) // 2
    c.create_rectangle(o, (size - arm) // 2, o + length, (size + arm) // 2, fill=theme.PRIMARY, outline="")
    c.create_rectangle((size - arm) // 2, o, (size + arm) // 2, o + length, fill=theme.PRIMARY, outline="")
    return c


def level_colors(level_name: str) -> tuple[str, str]:
    """(κείμενο, φόντο) για AVAILABLE / PARTIAL / NONE."""
    return {"AVAILABLE": (theme.SUCCESS, theme.SUCCESS_LIGHT),
            "PARTIAL": (theme.WARNING, theme.WARNING_LIGHT)}.get(level_name, (theme.DANGER, theme.DANGER_LIGHT))
