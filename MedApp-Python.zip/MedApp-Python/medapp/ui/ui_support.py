"""Κοινές βοηθητικές μέθοδοι για τις οθόνες."""
from collections.abc import Callable
from tkinter import messagebox
from typing import TypeVar

from medapp.service.validation_error import ValidationError

T = TypeVar("T")


def run(parent, action: Callable[[], T]) -> tuple[bool, T | None]:
    """Εκτελεί μια ενέργεια· σε αποτυχία δείχνει φιλικό μήνυμα. Επιστρέφει (επιτυχία, αποτέλεσμα)."""
    try:
        return True, action()
    except ValidationError as e:
        messagebox.showwarning("Προσοχή", str(e), parent=parent)
    except Exception as e:  # noqa: BLE001 - κάθε απρόσμενο σφάλμα εμφανίζεται στον χρήστη
        messagebox.showerror("Σφάλμα", f"Παρουσιάστηκε σφάλμα: {e}", parent=parent)
    return False, None
