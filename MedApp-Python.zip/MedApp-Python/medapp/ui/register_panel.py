"""Οθόνη εγγραφής νέου ασθενή με ΑΜΚΑ και κωδικό."""
import tkinter as tk
from tkinter import messagebox

from medapp.service.auth_service import AuthService
from medapp.ui import theme, ui_support
from medapp.ui.brand import split_screen
from medapp.ui.widgets import FlatButton, entry, label


class RegisterPanel(tk.Frame):
    def __init__(self, parent: tk.Misc, frame, auth_service: AuthService):
        super().__init__(parent, bg=theme.BACKGROUND)
        self.frame = frame
        self.auth_service = auth_service
        root, form = split_screen(self, "Δημιουργήστε λογαριασμό με τον ΑΜΚΑ σας μέσα σε ένα λεπτό.",
                                  ["Ο ΑΜΚΑ σας είναι το όνομα χρήστη", "Ο κωδικός αποθηκεύεται κρυπτογραφημένος",
                                   "Μετά την εγγραφή μπαίνετε αμέσως"])
        root.pack(fill="both", expand=True)

        label(form, "Νέος λογαριασμός", 20, True).grid(row=0, column=0, columnspan=2, sticky="w")
        label(form, "Τα πεδία με * είναι υποχρεωτικά", 11, fg=theme.MUTED).grid(
            row=1, column=0, columnspan=2, sticky="w", pady=(2, 14))
        self.amka = self._field(form, "ΑΜΚΑ *", 2, 0, span=2)
        self.first_name = self._field(form, "Όνομα *", 4, 0)
        self.last_name = self._field(form, "Επώνυμο *", 4, 1)
        self.phone = self._field(form, "Τηλέφωνο", 6, 0)
        self.email = self._field(form, "Email", 6, 1)
        self.password = self._field(form, f"Κωδικός * (τουλ. {AuthService.MIN_PASSWORD_LENGTH})", 8, 0, show="•")
        self.confirm = self._field(form, "Επιβεβαίωση κωδικού *", 8, 1, show="•")
        FlatButton(form, "Εγγραφή", FlatButton.PRIMARY, self.submit, pady=9).grid(
            row=10, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        FlatButton(form, "Έχω ήδη λογαριασμό", FlatButton.SECONDARY, frame.show_login, pady=9).grid(
            row=11, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        form.columnconfigure(0, weight=1, uniform="col")
        form.columnconfigure(1, weight=1, uniform="col")

    @staticmethod
    def _field(form: tk.Frame, text: str, row: int, col: int, span: int = 1, show: str | None = None) -> tk.Entry:
        padx = (0, 7) if col == 0 and span == 1 else (7, 0) if col == 1 else 0
        label(form, text, 10, True, fg=theme.MUTED).grid(row=row, column=col, columnspan=span, sticky="w", padx=padx)
        e = entry(form, show=show)
        e.configure(width=22)
        e.grid(row=row + 1, column=col, columnspan=span, sticky="ew", ipady=6, pady=(4, 10), padx=padx)
        return e

    def submit(self) -> None:
        """Εγγραφή (το όνομα register το χρησιμοποιεί ήδη το Tkinter)."""
        ok, patient = ui_support.run(self, lambda: self.auth_service.register(
            self.amka.get(), self.first_name.get(), self.last_name.get(), self.phone.get(), self.email.get(),
            self.password.get(), self.confirm.get()))
        if ok and patient is not None:
            messagebox.showinfo("MedApp", "Η εγγραφή ολοκληρώθηκε. Καλώς ήρθατε!", parent=self)
            self.frame.show_home(patient)

    def reset(self) -> None:
        for e in (self.amka, self.first_name, self.last_name, self.phone, self.email, self.password, self.confirm):
            e.delete(0, "end")
        self.amka.focus_set()
