"""Αρχική οθόνη συνδεδεμένου ασθενή: μπάρα εφαρμογής και δύο ενότητες."""
import tkinter as tk

from medapp.model.patient import Patient
from medapp.service.appointment_service import AppointmentService
from medapp.service.doctor_service import DoctorService
from medapp.ui import theme
from medapp.ui.my_appointments_panel import MyAppointmentsPanel
from medapp.ui.search_doctor_panel import SearchDoctorPanel
from medapp.ui.widgets import ChipButton, FlatButton, label, logo


class PatientHomePanel(tk.Frame):
    NEW = "Νέο ραντεβού"
    MINE = "Τα ραντεβού μου"

    def __init__(self, parent: tk.Misc, frame, patient: Patient, doctor_service: DoctorService,
                 appointment_service: AppointmentService):
        super().__init__(parent, bg=theme.BACKGROUND)
        bar = tk.Frame(self, bg=theme.PRIMARY, padx=20, pady=10)
        bar.pack(fill="x")
        logo(bar, 32, theme.PRIMARY).pack(side="left")
        label(bar, "MedApp", 17, True, fg="#FFFFFF", bg=theme.PRIMARY).pack(side="left", padx=(10, 28))
        self.nav_new = ChipButton(bar, self.NEW, lambda: self.show(self.NEW), selected=True, on_dark=True)
        self.nav_mine = ChipButton(bar, self.MINE, lambda: self.show(self.MINE), on_dark=True)
        self.nav_new.pack(side="left", padx=3)
        self.nav_mine.pack(side="left", padx=3)
        FlatButton(bar, "Αποσύνδεση", FlatButton.ON_DARK, frame.logout).pack(side="right")
        who = tk.Frame(bar, bg=theme.PRIMARY)
        who.pack(side="right", padx=14)
        label(who, patient.full_name, 11, True, fg="#FFFFFF", bg=theme.PRIMARY).pack(anchor="e")
        label(who, f"ΑΜΚΑ {patient.amka}", 9, fg="#DCE8F8", bg=theme.PRIMARY).pack(anchor="e")

        body = tk.Frame(self, bg=theme.BACKGROUND, padx=20, pady=16)
        body.pack(fill="both", expand=True)
        self.my_appointments = MyAppointmentsPanel(body, patient, appointment_service)
        self.search = SearchDoctorPanel(body, patient, doctor_service, appointment_service,
                                        on_booked=self.my_appointments.refresh)
        self.show(self.NEW)

    def show(self, section: str) -> None:
        self.nav_new.set_selected(section == self.NEW)
        self.nav_mine.set_selected(section == self.MINE)
        if section == self.NEW:
            self.my_appointments.pack_forget()
            self.search.pack(fill="both", expand=True)
        else:
            self.search.pack_forget()
            self.my_appointments.refresh()
            self.my_appointments.pack(fill="both", expand=True)
