"""Κύριο παράθυρο: εναλλάσσει τις οθόνες σύνδεσης, εγγραφής και ασθενή."""
import tkinter as tk

from medapp.model.patient import Patient
from medapp.service.appointment_service import AppointmentService
from medapp.service.auth_service import AuthService
from medapp.service.doctor_service import DoctorService
from medapp.ui import theme
from medapp.ui.login_panel import LoginPanel
from medapp.ui.patient_home_panel import PatientHomePanel
from medapp.ui.register_panel import RegisterPanel


class MainFrame(tk.Tk):
    def __init__(self, auth_service: AuthService, doctor_service: DoctorService,
                 appointment_service: AppointmentService):
        super().__init__()
        theme.install(self)
        self.title("MedApp – Ραντεβού με Ιατρούς")
        self.geometry("1180x760")
        self.minsize(1000, 680)
        self.doctor_service = doctor_service
        self.appointment_service = appointment_service
        self.login_panel = LoginPanel(self, self, auth_service)
        self.register_panel = RegisterPanel(self, self, auth_service)
        self.home_panel: PatientHomePanel | None = None
        self.current: tk.Frame | None = None
        self.show_login()

    def _show(self, panel: tk.Frame) -> None:
        if self.current is not None:
            self.current.pack_forget()
        panel.pack(fill="both", expand=True)
        self.current = panel

    def show_login(self) -> None:
        self.login_panel.reset()
        self._show(self.login_panel)

    def show_register(self) -> None:
        self.register_panel.reset()
        self._show(self.register_panel)

    def show_home(self, patient: Patient) -> None:
        """Μετά από επιτυχή σύνδεση ή εγγραφή."""
        if self.home_panel is not None:
            self.home_panel.destroy()
        self.home_panel = PatientHomePanel(self, self, patient, self.doctor_service, self.appointment_service)
        self._show(self.home_panel)

    def logout(self) -> None:
        if self.home_panel is not None:
            self.home_panel.destroy()
            self.home_panel = None
            self.current = None
        self.show_login()
