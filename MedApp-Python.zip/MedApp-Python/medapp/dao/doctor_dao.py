"""Πρόσβαση στον πίνακα doctors."""
import sqlite3

from medapp.dao.database import Database, DataAccessError
from medapp.model.doctor import Doctor


class DoctorDAO:
    SQL_SPECIALTIES = "SELECT DISTINCT specialty FROM doctors"
    SQL_AREAS = "SELECT DISTINCT area FROM doctors WHERE specialty = ?"
    SQL_SEARCH = "SELECT * FROM doctors WHERE specialty = ? AND area IN ({}) ORDER BY area, last_name, first_name"
    SQL_BY_AMKA = "SELECT * FROM doctors WHERE amka = ?"

    def __init__(self, db: Database):
        self.db = db

    def find_all_specialties(self) -> list[str]:
        return self._query_strings(self.SQL_SPECIALTIES, ())

    def find_areas_by_specialty(self, specialty: str) -> list[str]:
        return self._query_strings(self.SQL_AREAS, (specialty,))

    def find_by_specialty_and_areas(self, specialty: str, areas: list[str]) -> list[Doctor]:
        """Ιατροί μιας ειδικότητας σε μία ή περισσότερες περιοχές."""
        if not areas:
            return []
        sql = self.SQL_SEARCH.format(", ".join("?" * len(areas)))
        try:
            with self.db.connect() as c:
                return [self.map(r) for r in c.execute(sql, (specialty, *areas))]
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία αναζήτησης ιατρών") from e

    def find_by_amka(self, amka: str) -> Doctor | None:
        try:
            with self.db.connect() as c:
                row = c.execute(self.SQL_BY_AMKA, (amka,)).fetchone()
                return self.map(row) if row else None
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης ιατρού") from e

    def _query_strings(self, sql: str, params: tuple) -> list[str]:
        try:
            with self.db.connect() as c:
                return [r[0] for r in c.execute(sql, params)]
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης λίστας") from e

    @staticmethod
    def map(row: sqlite3.Row) -> Doctor:
        return Doctor(row["amka"], row["first_name"], row["last_name"], row["specialty"],
                      row["phone"], row["email"], row["area"], row["address"])
