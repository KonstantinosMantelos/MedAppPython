"""Πρόσβαση στον πίνακα appointments."""
import sqlite3
from datetime import date, datetime, time

from medapp.dao.database import Database, DataAccessError
from medapp.dao.doctor_dao import DoctorDAO
from medapp.model.appointment import Appointment
from medapp.model.appointment_status import AppointmentStatus


class AppointmentDAO:
    SQL_INSERT = ("INSERT INTO appointments (patient_amka, doctor_amka, appt_date, appt_time, reason, status, "
                  "created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
    SQL_BOOKED_TIMES = ("SELECT appt_time FROM appointments "
                        "WHERE doctor_amka = ? AND appt_date = ? AND status = 'ACTIVE'")
    SQL_PATIENT_TIMES = ("SELECT appt_time FROM appointments "
                         "WHERE patient_amka = ? AND appt_date = ? AND status = 'ACTIVE'")
    SQL_SELECT_JOIN = ("SELECT a.*, d.amka, d.first_name, d.last_name, d.specialty, d.phone, d.email, d.area, "
                       "d.address FROM appointments a JOIN doctors d ON d.amka = a.doctor_amka ")
    SQL_BY_ID = SQL_SELECT_JOIN + "WHERE a.id = ?"
    SQL_BY_PATIENT_PERIOD = (SQL_SELECT_JOIN + "WHERE a.patient_amka = ? AND a.appt_date BETWEEN ? AND ? "
                             "ORDER BY a.appt_date, a.appt_time")
    SQL_UPDATE_STATUS = "UPDATE appointments SET status = ? WHERE id = ?"

    def __init__(self, db: Database):
        self.db = db

    def insert(self, a: Appointment) -> int:
        """Αποθηκεύει το ραντεβού και επιστρέφει τον κωδικό του."""
        try:
            with self.db.connect() as c:
                cur = c.execute(self.SQL_INSERT, (a.patient_amka, a.doctor.amka, a.date.isoformat(),
                                                  a.time.strftime("%H:%M"), a.reason, a.status.name,
                                                  a.created_at.isoformat(timespec="seconds")))
                a.id = cur.lastrowid or 0
                return a.id
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία καταχώρησης ραντεβού") from e

    def find_booked_times(self, doctor_amka: str, day: date) -> list[time]:
        return self._times(self.SQL_BOOKED_TIMES, doctor_amka, day)

    def find_patient_booked_times(self, patient_amka: str, day: date) -> list[time]:
        """Οι ώρες έναρξης των ενεργών ραντεβού του ασθενή μια ημέρα."""
        return self._times(self.SQL_PATIENT_TIMES, patient_amka, day)

    def find_by_id(self, appointment_id: int) -> Appointment | None:
        try:
            with self.db.connect() as c:
                r = c.execute(self.SQL_BY_ID, (appointment_id,)).fetchone()
                return self._map(r) if r else None
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης ραντεβού") from e

    def find_by_patient_and_period(self, patient_amka: str, start: date, end: date) -> list[Appointment]:
        try:
            with self.db.connect() as c:
                return [self._map(r) for r in c.execute(self.SQL_BY_PATIENT_PERIOD,
                                                         (patient_amka, start.isoformat(), end.isoformat()))]
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης ραντεβού ασθενή") from e

    def update_status(self, appointment_id: int, status: AppointmentStatus) -> None:
        try:
            with self.db.connect() as c:
                c.execute(self.SQL_UPDATE_STATUS, (status.name, appointment_id))
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ενημέρωσης ραντεβού") from e

    def _times(self, sql: str, amka: str, day: date) -> list[time]:
        try:
            with self.db.connect() as c:
                return [time.fromisoformat(r[0]) for r in c.execute(sql, (amka, day.isoformat()))]
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης διαθεσιμότητας") from e

    @staticmethod
    def _map(r: sqlite3.Row) -> Appointment:
        return Appointment(r["id"], r["patient_amka"], DoctorDAO.map(r), date.fromisoformat(r["appt_date"]),
                           time.fromisoformat(r["appt_time"]), r["reason"], AppointmentStatus[r["status"]],
                           datetime.fromisoformat(r["created_at"]))
