"""Σύνδεση με τη βάση SQLite και αρχικοποίηση σχήματος/δεδομένων."""
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

RESOURCES = Path(__file__).resolve().parent.parent / "resources"


class DataAccessError(Exception):
    """Σφάλμα πρόσβασης στη βάση δεδομένων (τυλίγει το sqlite3.Error)."""


class Database:
    def __init__(self, file_name: str):
        self.file_name = file_name

    def get_connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.file_name)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Σύνδεση που κάνει commit στο τέλος (ή rollback σε σφάλμα) και μετά κλείνει."""
        connection = self.get_connection()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        """Δημιουργεί τους πίνακες και φορτώνει ιατρούς, ωράρια και λόγους επίσκεψης.

        Τα σενάρια δεδομένων ξανατρέχουν με ασφάλεια σε κάθε εκκίνηση (χωρίς διπλότυπα),
        ώστε και μια παλιότερη βάση να αποκτά τους νέους ιατρούς χωρίς να χαθούν τα ραντεβού της.
        """
        for script in ("schema.sql", "data.sql", "visit_reasons.sql"):
            self._run_script(script)

    def _run_script(self, name: str) -> None:
        sql = (RESOURCES / name).read_text(encoding="utf-8")
        try:
            connection = self.get_connection()
            try:
                connection.executescript("BEGIN;\n" + sql + "\nCOMMIT;")
            finally:
                connection.close()
        except sqlite3.Error as e:
            raise DataAccessError(f"Αποτυχία εκτέλεσης {name}: {e}") from e
