"""Πρόσβαση στον πίνακα patients."""
import sqlite3
from datetime import datetime

from medapp.dao.database import Database, DataAccessError
from medapp.model.patient import Patient


class PatientDAO:
    SQL_INSERT = ("INSERT INTO patients (amka, first_name, last_name, phone, email, password_hash, salt, created_at) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
    SQL_BY_AMKA = "SELECT * FROM patients WHERE amka = ?"

    def __init__(self, db: Database):
        self.db = db

    def exists(self, amka: str) -> bool:
        return self.find_by_amka(amka) is not None

    def insert(self, p: Patient) -> None:
        try:
            with self.db.connect() as c:
                c.execute(self.SQL_INSERT, (p.amka, p.first_name, p.last_name, p.phone, p.email,
                                            p.password_hash, p.salt, p.created_at.isoformat(timespec="seconds")))
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία εγγραφής ασθενή") from e

    def find_by_amka(self, amka: str) -> Patient | None:
        try:
            with self.db.connect() as c:
                r = c.execute(self.SQL_BY_AMKA, (amka,)).fetchone()
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης ασθενή") from e
        if r is None:
            return None
        return Patient(r["amka"], r["first_name"], r["last_name"], r["phone"], r["email"],
                       r["password_hash"], r["salt"], datetime.fromisoformat(r["created_at"]))
