"""Αναζήτηση ιατρών ανά ειδικότητα και περιοχές· λόγοι επίσκεψης."""
from medapp.dao.doctor_dao import DoctorDAO
from medapp.dao.visit_reason_dao import VisitReasonDAO
from medapp.model.doctor import Doctor
from medapp.service.validation_error import ValidationError
from medapp.util.date_utils import DateUtils


class DoctorService:
    OTHER_REASON = "Άλλο"
    """Η επιλογή που επιτρέπει στον ασθενή να γράψει δικό του λόγο."""

    def __init__(self, doctor_dao: DoctorDAO, visit_reason_dao: VisitReasonDAO):
        self.doctor_dao = doctor_dao
        self.visit_reason_dao = visit_reason_dao

    def get_specialties(self) -> list[str]:
        return sorted(self.doctor_dao.find_all_specialties(), key=DateUtils.greek_sort_key)

    def get_areas(self, specialty: str) -> list[str]:
        return sorted(self.doctor_dao.find_areas_by_specialty(specialty), key=DateUtils.greek_sort_key)

    def find_doctors(self, specialty: str | None, areas: list[str] | None) -> list[Doctor]:
        """Ιατροί της ειδικότητας σε όλες τις επιλεγμένες περιοχές μαζί."""
        if specialty is None:
            raise ValidationError("Επιλέξτε ειδικότητα.")
        if not areas:
            raise ValidationError("Επιλέξτε τουλάχιστον μία περιοχή.")
        return self.doctor_dao.find_by_specialty_and_areas(specialty, areas)

    def get_visit_reasons(self, doctor: Doctor) -> list[str]:
        """Οι 3 προκαθορισμένοι λόγοι επίσκεψης του ιατρού και στο τέλος η επιλογή «Άλλο»."""
        return [*self.visit_reason_dao.find_by_doctor(doctor.amka), self.OTHER_REASON]

    def resolve_reason(self, selected_option: str | None, other_text: str | None) -> str:
        """Ο λόγος που θα αποθηκευτεί: η επιλογή από τη λίστα ή, με «Άλλο», το κείμενο του ασθενή."""
        if selected_option is None:
            raise ValidationError("Επιλέξτε λόγο επίσκεψης.")
        if selected_option == self.OTHER_REASON:
            text = (other_text or "").strip()
            if not text:
                raise ValidationError("Γράψτε τον λόγο της επίσκεψης στο πεδίο «Άλλο».")
            return text
        return selected_option
