"""Παραβίαση επιχειρησιακού κανόνα· το μήνυμα εμφανίζεται στον χρήστη."""


class ValidationError(Exception):
    pass
