"""MedApp – Ραντεβού ασθενών με ιατρούς.

Σημείο εκκίνησης: δημιουργεί βάση, DAO, υπηρεσίες και το κύριο παράθυρο.
Εκτέλεση:  python app.py   (προαιρετικά: python app.py άλλο_αρχείο.db)
"""
import sys
from pathlib import Path
from tkinter import messagebox

from medapp.dao.appointment_dao import AppointmentDAO
from medapp.dao.database import Database
from medapp.dao.doctor_dao import DoctorDAO
from medapp.dao.patient_dao import PatientDAO
from medapp.dao.visit_reason_dao import VisitReasonDAO
from medapp.dao.working_hours_dao import WorkingHoursDAO
from medapp.service.appointment_service import AppointmentService
from medapp.service.auth_service import AuthService
from medapp.service.doctor_service import DoctorService

DB_FILE = str(Path(__file__).resolve().parent / "medapp.db")   # δίπλα στο app.py
DEMO_AMKA = "01019000015"
DEMO_PASSWORD = "demo123"


def main() -> None:
    db = Database(sys.argv[1] if len(sys.argv) > 1 else DB_FILE)
    try:
        db.initialize()
    except Exception as e:  # noqa: BLE001
        messagebox.showerror("MedApp", f"Αδυναμία σύνδεσης με τη βάση: {e}")
        return
    patient_dao = PatientDAO(db)
    auth_service = AuthService(patient_dao)
    doctor_service = DoctorService(DoctorDAO(db), VisitReasonDAO(db))
    appointment_service = AppointmentService(AppointmentDAO(db), WorkingHoursDAO(db))
    if not patient_dao.exists(DEMO_AMKA):
        auth_service.register(DEMO_AMKA, "Κώστας", "Δοκιμαστικός", "6900000000", "demo@medapp.example",
                              DEMO_PASSWORD, DEMO_PASSWORD)

    if sys.platform == "win32":                     # καθαρά γράμματα σε οθόνες υψηλής ανάλυσης
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:  # noqa: BLE001
            pass
    from medapp.ui.main_frame import MainFrame      # το Tkinter φορτώνεται μόνο για το παράθυρο
    MainFrame(auth_service, doctor_service, appointment_service).mainloop()


if __name__ == "__main__":
    main()
