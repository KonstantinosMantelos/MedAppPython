"""Τα tests της εφαρμογής.

Κάθε test φτιάχνει μια καινούργια, προσωρινή βάση SQLite με όλους τους ιατρούς, κάνει μια
δουλειά (εγγραφή, κράτηση, ακύρωση...) και ελέγχει ότι το αποτέλεσμα είναι το σωστό. Στο
τέλος η βάση σβήνεται, οπότε το medapp.db σου δεν πειράζεται ποτέ.

Τρέχουν με (από τον φάκελο του έργου):  python -m unittest -v
"""
import os
import tempfile
import unittest
from datetime import date, datetime, time

from medapp.dao.appointment_dao import AppointmentDAO
from medapp.dao.database import Database
from medapp.dao.doctor_dao import DoctorDAO
from medapp.dao.patient_dao import PatientDAO
from medapp.dao.visit_reason_dao import VisitReasonDAO
from medapp.dao.working_hours_dao import WorkingHoursDAO
from medapp.model.appointment import Appointment
from medapp.model.appointment_status import AppointmentStatus
from medapp.model.availability_level import AvailabilityLevel
from medapp.service.appointment_service import AppointmentService
from medapp.service.auth_service import AuthService
from medapp.service.doctor_service import DoctorService
from medapp.service.validation_error import ValidationError
from medapp.util.amka_validator import AmkaValidator

# «Παγώνουμε» την ώρα σε Δευτέρα 09/11/2026 15:00. Έτσι τα tests βγάζουν πάντα το ίδιο αποτέλεσμα,
# ό,τι μέρα κι αν τα τρέξεις (αλλιώς ένα ραντεβού «την Τετάρτη» θα ήταν κάποια στιγμή στο παρελθόν).
NOW = datetime(2026, 11, 9, 15, 0)
WED, THU, FRI = date(2026, 11, 11), date(2026, 11, 12), date(2026, 11, 13)
T0900, T1030, T1200, T1330 = time(9, 0), time(10, 30), time(12, 0), time(13, 30)


class AppointmentServiceTest(unittest.TestCase):
    # Το setUp τρέχει πριν από ΚΑΘΕ test: νέα βάση, δύο ασθενείς και ο ιατρός με τον οποίο δοκιμάζουμε.
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(os.path.join(self.tmp.name, "test.db"))
        self.db.initialize()
        clock = lambda: NOW  # noqa: E731
        self.auth = AuthService(PatientDAO(self.db), clock)
        self.doctors = DoctorService(DoctorDAO(self.db), VisitReasonDAO(self.db))
        self.appointments = AppointmentService(AppointmentDAO(self.db), WorkingHoursDAO(self.db), clock)
        self.patient = self.auth.register("01019000015", "Κώστας", "Δοκιμαστικός", "", "", "demo123", "demo123")
        self.other = self.auth.register("15059501237", "Άννα", "Β", "", "", "abcdef", "abcdef")
        # Παπαδόπουλος: Δευτέρα, Τετάρτη, Παρασκευή 09:00-15:00 → 09:00, 10:30, 12:00, 13:30
        self.doctor = self.doctors.find_doctors("Παθολόγος", ["Αθήνα"])[0]

    # Το tearDown τρέχει μετά από κάθε test και σβήνει την προσωρινή βάση.
    def tearDown(self):
        self.tmp.cleanup()

    # Βοηθός: οι ελεύθερες ώρες του ιατρού μια μέρα, σαν απλή λίστα από ώρες.
    def free_times(self, day):
        return [s.time for s in self.appointments.get_available_slots(self.doctor, day)]

    # ---------- εγγραφή / σύνδεση ----------
    # Τα assertRaises ελέγχουν ότι κάτι ΑΠΟΤΥΓΧΑΝΕΙ όπως πρέπει (π.χ. λάθος κωδικός).

    def test_amka_validation(self):
        self.assertTrue(AmkaValidator.is_valid("01019000015"))
        self.assertFalse(AmkaValidator.is_valid("01019000016"))
        self.assertFalse(AmkaValidator.is_valid("abc"))

    def test_register_rules(self):
        with self.assertRaises(ValidationError):
            self.auth.register("01019000015", "Α", "Β", "", "", "123456", "123456")   # υπάρχει ήδη
        with self.assertRaises(ValidationError):
            self.auth.register("05059501231", "Α", "Β", "", "", "123", "123")         # κοντός κωδικός
        with self.assertRaises(ValidationError):
            self.auth.register("05059501231", "Α", "Β", "", "", "123456", "654321")   # δεν ταιριάζουν
        self.assertNotEqual("demo123", self.patient.password_hash)                   # αποθηκεύεται μόνο hash

    def test_login_requires_correct_password(self):
        self.assertEqual("01019000015", self.auth.login("01019000015", "demo123").amka)
        with self.assertRaises(ValidationError):
            self.auth.login("01019000015", "wrong1")

    # ---------- αναζήτηση ----------

    def test_search_by_specialty_and_area(self):
        self.assertEqual(15, len(self.doctors.get_specialties()))
        self.assertIn("Περιστέρι", self.doctors.get_areas("Παθολόγος"))
        self.assertEqual("Παπαδόπουλος", self.doctor.last_name)

    def test_search_in_several_areas_at_once(self):
        both = self.doctors.find_doctors("Οφθαλμίατρος", ["Αθήνα", "Πειραιάς"])
        self.assertEqual(2, len(both))
        self.assertEqual(1, len(self.doctors.find_doctors("Οφθαλμίατρος", ["Πειραιάς"])))
        self.assertEqual(6, len(self.doctors.find_doctors("Οφθαλμίατρος", self.doctors.get_areas("Οφθαλμίατρος"))))
        with self.assertRaises(ValidationError):
            self.doctors.find_doctors("Οφθαλμίατρος", [])
        self.assertIsNotNone(self.appointments.find_next_available(both[0]))

    # ---------- πρόγραμμα και διαθεσιμότητα ----------
    # Εδώ ελέγχουμε τους βασικούς κανόνες: 4 ραντεβού τη μέρα και τα χρώματα.

    def test_four_ninety_minute_appointments_per_day(self):
        self.assertEqual([T0900, T1030, T1200, T1330], self.free_times(WED))
        self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        self.appointments.book(self.other, self.doctor, WED, T1030, "Β")
        self.appointments.book(self.patient, self.doctor, WED, T1200, "Γ")
        self.appointments.book(self.other, self.doctor, WED, T1330, "Δ")
        self.assertEqual([], self.free_times(WED))                     # 4 ραντεβού → πλήρης
        with self.assertRaises(ValidationError):
            self.appointments.book(self.patient, self.doctor, WED, T1330, "Ε")

    def test_availability_levels_per_day(self):
        for free, level in [(4, AvailabilityLevel.AVAILABLE), (3, AvailabilityLevel.AVAILABLE),
                            (2, AvailabilityLevel.PARTIAL), (1, AvailabilityLevel.PARTIAL),
                            (0, AvailabilityLevel.NONE)]:
            self.assertEqual(level, AppointmentService.classify(free))
        self.assertTrue(self.appointments.is_working_day(self.doctor, WED))
        self.assertFalse(self.appointments.is_working_day(self.doctor, THU))
        self.assertEqual(AvailabilityLevel.AVAILABLE, self.appointments.get_availability_level(self.doctor, WED))
        self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        self.appointments.book(self.other, self.doctor, WED, T1030, "Β")
        self.assertEqual(AvailabilityLevel.PARTIAL, self.appointments.get_availability_level(self.doctor, WED))
        self.appointments.book(self.patient, self.doctor, WED, T1200, "Γ")
        self.appointments.book(self.other, self.doctor, WED, T1330, "Δ")
        self.assertEqual(AvailabilityLevel.NONE, self.appointments.get_availability_level(self.doctor, WED))
        nxt = self.appointments.find_next_available(self.doctor, THU)  # πλήρης Τετάρτη → Παρασκευή 09:00
        assert nxt is not None
        self.assertEqual((FRI, T0900), (nxt.date, nxt.time))

    def test_today_only_future_slots_count(self):
        # Είναι Δευτέρα 15:00 και το ιατρείο κλείνει 15:00, άρα σήμερα δεν μένει τίποτα ελεύθερο.
        self.assertTrue(self.appointments.is_working_day(self.doctor, NOW.date()))
        self.assertEqual(AvailabilityLevel.NONE, self.appointments.get_availability_level(self.doctor, NOW.date()))

    # ---------- κράτηση ----------

    def test_book_cancel_and_rebook(self):
        self.assertEqual(4, len(self.free_times(WED)))
        a = self.appointments.book(self.patient, self.doctor, WED, T0900, "Πυρετός")
        self.assertEqual(3, len(self.free_times(WED)))
        with self.assertRaises(ValidationError):
            self.appointments.book(self.other, self.doctor, WED, T0900, "Ξανά")
        self.appointments.cancel(self.patient, a.id)
        self.assertEqual(4, len(self.free_times(WED)))
        self.appointments.book(self.other, self.doctor, WED, T0900, "Νέα κράτηση")

    def test_rejects_past_times_empty_reason_and_far_dates(self):
        with self.assertRaises(ValidationError):
            self.appointments.book(self.patient, self.doctor, NOW.date(), T0900, "x")
        with self.assertRaises(ValidationError):
            self.appointments.book(self.patient, self.doctor, WED, T0900, " ")
        with self.assertRaises(ValidationError):
            self.appointments.book(self.patient, self.doctor, date(2026, 12, 14), T0900, "x")
        with self.assertRaises(ValidationError):
            self.appointments.book(self.patient, self.doctor, WED, time(9, 10), "x")       # εκτός πλέγματος

    def test_patient_cannot_have_overlapping_appointments(self):
        all_doctors = [d for sp in self.doctors.get_specialties()
                       for d in self.doctors.find_doctors(sp, self.doctors.get_areas(sp))]
        other_doctor = next(d for d in all_doctors
                            if d != self.doctor and self.appointments.is_working_day(d, WED))
        self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        with self.assertRaises(ValidationError):                        # ίδια ώρα με άλλο ραντεβού του
            self.appointments.book(self.patient, other_doctor, WED, T0900, "Β")
        self.appointments.book(self.patient, other_doctor, WED, T1030, "Γ")   # 10:30 = ακριβώς 1,5 ώρα, επιτρέπεται

    def test_visit_reasons_three_plus_other(self):
        reasons = self.doctors.get_visit_reasons(self.doctor)
        self.assertEqual(4, len(reasons))
        self.assertEqual(DoctorService.OTHER_REASON, reasons[3])
        self.assertEqual(reasons[0], self.doctors.resolve_reason(reasons[0], "αγνοείται"))
        self.assertEqual("Πόνος στο αυτί", self.doctors.resolve_reason(DoctorService.OTHER_REASON, "  Πόνος στο αυτί "))
        with self.assertRaises(ValidationError):
            self.doctors.resolve_reason(DoctorService.OTHER_REASON, " ")
        with self.assertRaises(ValidationError):
            self.doctors.resolve_reason(None, "")

    # ---------- ακύρωση ----------

    def test_cancel_rules(self):
        a = self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        with self.assertRaises(ValidationError):
            self.appointments.cancel(self.other, a.id)                  # όχι δικό του
        self.appointments.cancel(self.patient, a.id)
        with self.assertRaises(ValidationError):
            self.appointments.cancel(self.patient, a.id)                # ήδη ακυρωμένο
        past = Appointment(9, "x", self.doctor, date(2026, 11, 2), T0900, "r", AppointmentStatus.ACTIVE, NOW)
        self.assertEqual(AppointmentStatus.COMPLETED, past.get_effective_status(NOW))
        self.assertFalse(past.is_cancellable(NOW))

    def test_bulk_cancel_is_all_or_nothing(self):
        a = self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        b = self.appointments.book(self.patient, self.doctor, WED, T1030, "Β")
        c = self.appointments.book(self.patient, self.doctor, date(2026, 11, 16), T1200, "Γ")
        self.appointments.cancel(self.patient, c.id)
        with self.assertRaises(ValidationError):                        # το c είναι ήδη ακυρωμένο
            self.appointments.cancel_all(self.patient, [a.id, c.id])
        active = lambda: [x for x in self.appointments.get_weekly_appointments(self.patient, WED)  # noqa: E731
                          if x.status == AppointmentStatus.ACTIVE]
        self.assertEqual(2, len(active()))                              # κανένα δεν ακυρώθηκε
        self.assertEqual(2, self.appointments.cancel_all(self.patient, [a.id, b.id, a.id]))
        self.assertEqual(0, len(active()))
        with self.assertRaises(ValidationError):
            self.appointments.cancel_all(self.patient, [])

    # ---------- προβολή ----------

    def test_weekly_and_monthly_views(self):
        self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        self.appointments.book(self.patient, self.doctor, date(2026, 11, 16), T1030, "Β")
        self.appointments.book(self.patient, self.doctor, date(2026, 11, 30), T1200, "Γ")
        self.assertEqual(1, len(self.appointments.get_weekly_appointments(self.patient, date(2026, 11, 13))))
        self.assertEqual(1, len(self.appointments.get_weekly_appointments(self.patient, date(2026, 11, 22))))
        self.assertEqual(3, len(self.appointments.get_monthly_appointments(self.patient, 2026, 11)))

    # Η εφαρμογή ξανατρέχει τα .sql σε κάθε εκκίνηση. Εδώ βεβαιωνόμαστε ότι αυτό δεν σβήνει
    # ραντεβού και δεν διπλασιάζει τους ιατρούς.
    def test_reinitialize_keeps_appointments(self):
        self.appointments.book(self.patient, self.doctor, WED, T0900, "Α")
        self.db.initialize()                                             # όπως σε κάθε εκκίνηση
        self.assertEqual(3, len(self.free_times(WED)))
        with self.db.connect() as c:
            self.assertEqual(90, c.execute("SELECT COUNT(*) FROM doctors").fetchone()[0])


if __name__ == "__main__":
    unittest.main()
