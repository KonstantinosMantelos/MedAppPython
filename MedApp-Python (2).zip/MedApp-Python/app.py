"""MedApp – Ραντεβού ασθενών με ιατρούς.

Από εδώ ξεκινάνε όλα. Το αρχείο απλώς «συναρμολογεί» την εφαρμογή: ανοίγει τη βάση,
φτιάχνει τα DAO και τα services και στο τέλος ανοίγει το παράθυρο. Η πραγματική δουλειά
γίνεται μέσα στον φάκελο medapp.

Τρέχει με:  python app.py
(αν θες άλλο αρχείο βάσης, π.χ. για δοκιμές:  python app.py dokimi.db)
"""
import sys
from pathlib import Path
from tkinter import messagebox

from medapp.dao.appointment_dao import AppointmentDAO
from medapp.dao.database import Database
from medapp.dao.doctor_dao import DoctorDAO
from medapp.dao.patient_dao import PatientDAO
from medapp.dao.visit_reason_dao import VisitReasonDAO
from medapp.dao.working_hours_dao import WorkingHoursDAO
from medapp.service.appointment_service import AppointmentService
from medapp.service.auth_service import AuthService
from medapp.service.doctor_service import DoctorService

# Η βάση φτιάχνεται δίπλα στο app.py, ό,τι φάκελο κι αν τρέξεις την εντολή.
DB_FILE = str(Path(__file__).resolve().parent / "medapp.db")
# Ένας έτοιμος λογαριασμός, για να μπορεί κάποιος να δοκιμάσει την εφαρμογή αμέσως.
DEMO_AMKA = "01019000015"
DEMO_PASSWORD = "demo123"


def main() -> None:
    # 1) Η βάση: αν δεν υπάρχει, φτιάχνεται τώρα με όλους τους πίνακες και τους 90 ιατρούς.
    db = Database(sys.argv[1] if len(sys.argv) > 1 else DB_FILE)
    try:
        db.initialize()
    except Exception as e:  # noqa: BLE001
        messagebox.showerror("MedApp", f"Αδυναμία σύνδεσης με τη βάση: {e}")
        return
    # 2) Τα «κομμάτια» της εφαρμογής. Κάθε service παίρνει τα DAO που χρειάζεται
    #    (αυτό λέγεται dependency injection: τα δίνουμε απ' έξω αντί να τα φτιάχνει μόνο του,
    #    γι' αυτό και στα tests μπορούμε να δώσουμε μια προσωρινή βάση).
    patient_dao = PatientDAO(db)
    auth_service = AuthService(patient_dao)
    doctor_service = DoctorService(DoctorDAO(db), VisitReasonDAO(db))
    appointment_service = AppointmentService(AppointmentDAO(db), WorkingHoursDAO(db))
    # 3) Ο δοκιμαστικός χρήστης, μόνο την πρώτη φορά.
    if not patient_dao.exists(DEMO_AMKA):
        auth_service.register(DEMO_AMKA, "Κώστας", "Δοκιμαστικός", "6900000000", "demo@medapp.example",
                              DEMO_PASSWORD, DEMO_PASSWORD)

    # Στα Windows με οθόνες υψηλής ανάλυσης το Tkinter βγαίνει θολό. Αυτή η γραμμή το διορθώνει.
    # Αν αποτύχει για οποιονδήποτε λόγο, απλώς συνεχίζουμε· δεν είναι κρίσιμο.
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:  # noqa: BLE001
            pass
    # 4) Το παράθυρο. Το import το κάνουμε εδώ και όχι πάνω πάνω, για να μη χρειάζεται
    #    το Tkinter όποιος θέλει μόνο τη λογική (π.χ. τα tests).
    from medapp.ui.main_frame import MainFrame
    # Το mainloop() «κρατάει» το πρόγραμμα ανοιχτό και περιμένει κλικ μέχρι να κλείσει το παράθυρο.
    MainFrame(auth_service, doctor_service, appointment_service).mainloop()


# Αυτό σημαίνει: τρέξε τη main() μόνο αν ξεκίνησες αυτό το αρχείο απευθείας (python app.py),
# όχι αν κάποιο άλλο αρχείο το κάνει import.
if __name__ == "__main__":
    main()
