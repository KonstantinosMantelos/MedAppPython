"""Το «στήσιμο» των οθονών σύνδεσης και εγγραφής: μπλε πάνελ αριστερά, φόρμα σε κάρτα δεξιά.
Το έχουμε ξεχωριστά για να μη γράφουμε τα ίδια και στις δύο οθόνες."""
import tkinter as tk

from medapp.ui import theme
from medapp.ui.widgets import Card


class BrandPanel(tk.Canvas):
    """Το μπλε πάνελ με το λογότυπο και τα βήματα 1-2-3. Είναι Canvas, δηλαδή το ζωγραφίζουμε
    μόνοι μας (διαβάθμιση, κύκλους, κείμενα), γιατί έτσι έχουμε πλήρη έλεγχο στην εμφάνιση."""

    def __init__(self, parent: tk.Misc, subtitle: str, steps: list[str]):
        super().__init__(parent, width=400, bg=theme.PRIMARY, highlightthickness=0)
        self.subtitle = subtitle
        self.steps = steps
        # Το <Configure> έρχεται κάθε φορά που αλλάζει το μέγεθος του παραθύρου, οπότε
        # ξαναζωγραφίζουμε για να γεμίζει πάντα όλο το ύψος.
        self.bind("<Configure>", lambda e: self._draw())

    def _draw(self) -> None:
        self.delete("all")
        w, h = max(self.winfo_width(), 400), max(self.winfo_height(), 600)
        top, bottom = (0x15, 0x65, 0xC0), (0x0D, 0x47, 0xA1)
        # Το Tkinter δεν έχει έτοιμη διαβάθμιση, οπότε τη φτιάχνουμε με πολλές λεπτές λωρίδες,
        # η καθεμία λίγο πιο σκούρα από την προηγούμενη.
        for y in range(0, h, 4):
            k = y / h
            color = "#%02x%02x%02x" % tuple(int(a + (b - a) * k) for a, b in zip(top, bottom, strict=True))
            self.create_rectangle(0, y, w, y + 4, fill=color, outline="")
        self.create_oval(w - 200, h - 200, w + 120, h + 120, fill="#2A6FC6", outline="")
        # Από εδώ και κάτω: λογότυπο (κύκλος + σταυρός), τίτλος, υπότιτλος και βήματα.
        x, y = 44, 70
        self.create_oval(x, y, x + 56, y + 56, fill="#FFFFFF", outline="")
        self.create_rectangle(x + 17, y + 23, x + 39, y + 33, fill=theme.PRIMARY, outline="")
        self.create_rectangle(x + 23, y + 17, x + 33, y + 39, fill=theme.PRIMARY, outline="")
        self.create_text(x, y + 84, text="MedApp", anchor="nw", fill="#FFFFFF", font=theme.font(26, True))
        self.create_text(x, y + 132, text=self.subtitle, anchor="nw", fill="#DCE8F8", font=theme.font(12),
                         width=w - 2 * x)
        y += 210
        for i, step in enumerate(self.steps, 1):
            self.create_oval(x, y, x + 28, y + 28, outline="#FFFFFF", width=1.5, fill="#3B7AD0")
            self.create_text(x + 14, y + 14, text=str(i), fill="#FFFFFF", font=theme.font(10, True))
            self.create_text(x + 42, y + 14, text=step, anchor="w", fill="#FFFFFF", font=theme.font(11),
                             width=w - x - 70)
            y += 46


def split_screen(parent: tk.Misc, subtitle: str, steps: list[str]) -> tuple[tk.Frame, tk.Frame]:
    """Φτιάχνει όλο το στήσιμο και γυρνάει δύο πράγματα: τη ρίζα (για να την κάνει pack η οθόνη)
    και το πλαίσιο της φόρμας, όπου η οθόνη βάζει τα δικά της πεδία και κουμπιά."""
    root = tk.Frame(parent, bg=theme.BACKGROUND)
    BrandPanel(root, subtitle, steps).pack(side="left", fill="y")
    right = tk.Frame(root, bg=theme.BACKGROUND)
    right.pack(side="left", fill="both", expand=True)
    card = Card(right, padx=34, pady=30)
    # Με place στο 50%/50% η κάρτα μένει πάντα στο κέντρο, όσο κι αν μεγαλώσει το παράθυρο.
    card.place(relx=0.5, rely=0.5, anchor="center")
    form = tk.Frame(card, bg=theme.CARD)
    form.pack(fill="both", expand=True)
    return root, form
