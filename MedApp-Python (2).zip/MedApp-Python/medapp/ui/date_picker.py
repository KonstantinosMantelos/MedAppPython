"""Το «διαλέξε ημερομηνία» της αναζήτησης: ‹ [Τρίτη 10/11/2026 ▾] ›

Τα βελάκια πάνε μία μέρα πίσω/μπροστά και το κουμπί στη μέση ανοίγει ένα μικρό ημερολόγιο.
Το Tkinter δεν έχει έτοιμο ημερολόγιο, οπότε το φτιάξαμε μόνοι μας. Δεν σε αφήνει να
διαλέξεις μέρα πριν από σήμερα ή πέρα από τις 30 μέρες (min_date / max_date).
"""
import calendar
import tkinter as tk
from collections.abc import Callable
from datetime import date, timedelta

from medapp.ui import theme
from medapp.ui.widgets import FlatButton, label
from medapp.util.date_utils import DateUtils

WEEKDAYS = ["Δε", "Τρ", "Τε", "Πε", "Πα", "Σα", "Κυ"]


class DatePicker(tk.Frame):
    def __init__(self, parent: tk.Misc, initial: date, min_date: date, max_date: date, bg: str = theme.CARD):
        super().__init__(parent, bg=bg)
        self.min_date = min_date
        self.max_date = max_date
        # Όποιος θέλει να μαθαίνει πότε αλλάζει η ημερομηνία γράφεται εδώ (η αναζήτηση το κάνει,
        # για να ξαναψάχνει κάθε φορά που αλλάζει μέρα).
        self.listeners: list[Callable[[date], None]] = []
        self.date: date = initial
        self.popup: tk.Toplevel | None = None
        self.prev = FlatButton(self, "‹", FlatButton.SECONDARY, lambda: self.set_date(self.date - timedelta(days=1)),
                               size=13, padx=12, pady=3)
        self.field = FlatButton(self, "", FlatButton.SECONDARY, self.show_calendar, padx=18)
        self.next = FlatButton(self, "›", FlatButton.SECONDARY, lambda: self.set_date(self.date + timedelta(days=1)),
                               size=13, padx=12, pady=3)
        self.prev.pack(side="left")
        self.field.pack(side="left", padx=6)
        self.next.pack(side="left")
        self.set_date(initial, notify=False)

    def get_date(self) -> date:
        return self.date

    def add_date_listener(self, listener: Callable[[date], None]) -> None:
        self.listeners.append(listener)

    def set_date(self, d: date, notify: bool = True) -> None:
        # Αν ζητηθεί μέρα εκτός ορίων, τη «σπρώχνουμε» στο πιο κοντινό όριο.
        d = min(max(d, self.min_date), self.max_date)
        changed = d != self.date
        self.date = d
        self.field.configure(text=f"{DateUtils.format_long(d)}  ▾", width=24)
        # Στην πρώτη επιτρεπτή μέρα γκριζάρει το ‹ και στην τελευταία το ›.
        self.prev.set_enabled(d > self.min_date)
        self.next.set_enabled(d < self.max_date)
        if changed and notify:
            for listener in self.listeners:
                listener(d)

    # ---------- το αναδυόμενο ημερολόγιο ----------

    # Ανοίγει ένα μικρό παράθυρο χωρίς μπάρα τίτλου (overrideredirect) ακριβώς κάτω από το
    # κουμπί. Με το grab_set «κλέβει» όλα τα κλικ, για να ξέρουμε πότε πάτησε κάπου έξω.
    def show_calendar(self) -> None:
        self.close_calendar()
        popup = tk.Toplevel(self)
        popup.overrideredirect(True)
        popup.configure(bg=theme.BORDER)
        popup.geometry(f"+{self.field.winfo_rootx()}+{self.field.winfo_rooty() + self.field.winfo_height() + 4}")
        self.popup = popup
        self._month = (self.date.year, self.date.month)
        self._body = tk.Frame(popup, bg=theme.CARD, padx=12, pady=10)
        self._body.pack(padx=1, pady=1)
        self._build_month()
        popup.bind("<Escape>", lambda e: self.close_calendar())
        popup.bind("<Button-1>", self._click_outside)
        popup.wait_visibility()
        popup.focus_force()
        popup.grab_set()

    def close_calendar(self) -> None:
        if self.popup is not None:
            self.popup.grab_release()
            self.popup.destroy()
            self.popup = None

    # Κλικ έξω από το ημερολόγιο = το κλείνουμε, όπως κάνουν όλα τα αναδυόμενα μενού.
    def _click_outside(self, event: tk.Event) -> None:
        p = self.popup
        if p is None:
            return
        inside = (p.winfo_rootx() <= event.x_root <= p.winfo_rootx() + p.winfo_width()
                  and p.winfo_rooty() <= event.y_root <= p.winfo_rooty() + p.winfo_height())
        if not inside:
            self.close_calendar()

    def _move_month(self, delta: int) -> None:
        # Λίγα μαθηματικά για να περνάμε σωστά από Δεκέμβριο σε Ιανουάριο του επόμενου έτους.
        y, m = self._month
        m += delta
        self._month = (y + (m - 1) // 12, (m - 1) % 12 + 1)
        self._build_month()

    def _build_month(self) -> None:
        for w in self._body.winfo_children():
            w.destroy()
        y, m = self._month
        head = tk.Frame(self._body, bg=theme.CARD)
        head.pack(fill="x", pady=(0, 6))
        back = FlatButton(head, "‹", FlatButton.SECONDARY, lambda: self._move_month(-1), size=12, padx=10, pady=1)
        fwd = FlatButton(head, "›", FlatButton.SECONDARY, lambda: self._move_month(1), size=12, padx=10, pady=1)
        back.set_enabled((y, m) > (self.min_date.year, self.min_date.month))
        fwd.set_enabled((y, m) < (self.max_date.year, self.max_date.month))
        back.pack(side="left")
        fwd.pack(side="right")
        label(head, DateUtils.format_month(y, m), 12, True).pack(side="left", expand=True)

        grid = tk.Frame(self._body, bg=theme.CARD)
        grid.pack()
        for col, name in enumerate(WEEKDAYS):
            label(grid, name, 9, True, fg=theme.MUTED, width=4).grid(row=0, column=col, pady=(0, 4))
        # Το calendar της Python μας δίνει τον μήνα χωρισμένο σε εβδομάδες (Δευτέρα πρώτη),
        # οπότε απλώς βάζουμε κάθε μέρα στη σωστή γραμμή και στήλη.
        for row, week in enumerate(calendar.Calendar(firstweekday=0).monthdatescalendar(y, m), start=1):
            for col, day in enumerate(week):
                if day.month != m:          # μέρες του προηγούμενου/επόμενου μήνα: τις αφήνουμε κενές
                    continue
                self._day_cell(grid, day).grid(row=row, column=col, padx=1, pady=1)
        label(self._body, f"Ραντεβού έως {DateUtils.format_date(self.max_date)}", 9,
              fg=theme.MUTED).pack(anchor="w", pady=(6, 0))

    # Ένα κελί του ημερολογίου: μπλε αν είναι η επιλεγμένη μέρα, γκρι αν δεν επιτρέπεται.
    def _day_cell(self, parent: tk.Frame, day: date) -> tk.Label:
        allowed = self.min_date <= day <= self.max_date
        selected = day == self.date
        cell = tk.Label(parent, text=str(day.day), width=4, pady=4,
                        font=theme.font(10, selected),
                        bg=theme.PRIMARY if selected else theme.CARD,
                        fg="#FFFFFF" if selected else theme.TEXT if allowed else "#B8BEC7",
                        cursor="hand2" if allowed else "arrow")
        if allowed:
            if not selected:
                cell.bind("<Enter>", lambda e: cell.configure(bg=theme.PRIMARY_LIGHT))
                cell.bind("<Leave>", lambda e: cell.configure(bg=theme.CARD))
            # Το d=day είναι κόλπο της Python: «κλειδώνει» τη μέρα του κάθε κελιού. Χωρίς αυτό,
            # όλα τα κελιά θα διάλεγαν την τελευταία μέρα του βρόχου.
            cell.bind("<ButtonRelease-1>", lambda e, d=day: self._pick(d))
        return cell

    def _pick(self, day: date) -> None:
        self.close_calendar()
        self.set_date(day)
