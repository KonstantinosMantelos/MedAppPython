"""Ένας βοηθός που χρησιμοποιούν όλες οι οθόνες για να μη γράφουν παντού try/except."""
from collections.abc import Callable
from tkinter import messagebox
from typing import TypeVar

from medapp.service.validation_error import ValidationError

T = TypeVar("T")


def run(parent, action: Callable[[], T]) -> tuple[bool, T | None]:
    """Τρέχει μια ενέργεια (π.χ. «κλείσε το ραντεβού») και, αν αποτύχει, δείχνει μήνυμα.

    Αν είναι ValidationError (λάθος του χρήστη) βγάζει κίτρινη προειδοποίηση με το μήνυμά μας.
    Αν είναι κάτι απρόσμενο βγάζει κόκκινο σφάλμα, για να μην «κρασάρει» απλώς η εφαρμογή.
    Γυρνάει (True, αποτέλεσμα) αν πέτυχε ή (False, None) αν όχι.

    Παράδειγμα: ok, patient = run(self, lambda: auth.login(amka, password))
    """
    try:
        return True, action()
    except ValidationError as e:
        messagebox.showwarning("Προσοχή", str(e), parent=parent)
    except Exception as e:  # noqa: BLE001 - κάθε απρόσμενο σφάλμα εμφανίζεται στον χρήστη
        messagebox.showerror("Σφάλμα", f"Παρουσιάστηκε σφάλμα: {e}", parent=parent)
    return False, None
