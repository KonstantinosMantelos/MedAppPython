"""Τα χρώματα και οι γραμματοσειρές όλης της εφαρμογής, σε ένα σημείο.

Αν θέλεις π.χ. πράσινο αντί για μπλε, αλλάζεις το PRIMARY εδώ και αλλάζει παντού.
"""
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

# Η παλέτα. Το μπλε είναι το «ιατρικό» χρώμα μας, τα *_LIGHT είναι απαλές εκδοχές για φόντο.
PRIMARY = "#1565C0"
PRIMARY_DARK = "#0D47A1"
PRIMARY_LIGHT = "#E3EEFB"
BACKGROUND = "#F3F6FA"
CARD = "#FFFFFF"
BORDER = "#DCE3EC"
TEXT = "#1F2937"
MUTED = "#6B7280"
STRIPE = "#F7F9FC"
SUCCESS = "#2E7D32"
SUCCESS_LIGHT = "#E6F4EA"
WARNING = "#8A6100"
WARNING_LIGHT = "#FFF3CD"
DANGER = "#C62828"
DANGER_LIGHT = "#FDECEC"
NEUTRAL_LIGHT = "#EEF0F3"
CHIP_BORDER = "#B7CBE6"
ON_DARK = "#2F6FC8"
ON_DARK_HOVER = "#4A82D0"

# Ποια γραμματοσειρά θα χρησιμοποιήσουμε. Την αποφασίζει η install() πιο κάτω.
_family = "TkDefaultFont"


def install(root: tk.Tk) -> None:
    """Καλείται μία φορά στην αρχή, μόλις ανοίξει το παράθυρο.

    Διαλέγει την πρώτη γραμματοσειρά που υπάρχει στον υπολογιστή (Segoe UI στα Windows)
    και ρυθμίζει πώς φαίνονται οι πίνακες (Treeview) και οι λίστες (Combobox).
    """
    global _family
    available = set(tkfont.families(root))
    for f in ("Segoe UI", "Noto Sans", "DejaVu Sans", "Helvetica Neue", "Arial"):
        if f in available:
            _family = f
            break
    root.configure(bg=BACKGROUND)
    root.option_add("*Font", font(11))

    style = ttk.Style(root)
    # Το "clam" είναι το θέμα του ttk που μας αφήνει να αλλάξουμε χρώματα ελεύθερα
    # (τα θέματα των Windows αγνοούν πολλές ρυθμίσεις χρωμάτων).
    style.theme_use("clam")
    style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT,
                    rowheight=34, font=font(11), borderwidth=0)
    style.configure("Treeview.Heading", background="#F0F4F9", foreground=MUTED, font=font(10, True),
                    relief="flat", padding=(8, 8))
    style.map("Treeview", background=[("selected", PRIMARY_LIGHT)], foreground=[("selected", TEXT)])
    style.map("Treeview.Heading", background=[("active", "#E6ECF4")])
    style.configure("TCombobox", padding=6, fieldbackground=CARD, background=CARD, arrowcolor=PRIMARY)
    style.configure("Vertical.TScrollbar", background=BACKGROUND, troughcolor=CARD, bordercolor=CARD,
                    arrowcolor=MUTED)
    root.option_add("*TCombobox*Listbox.font", font(11))


# Μικρός βοηθός: font(12, True) → ("Segoe UI", 12, "bold"). Έτσι δεν γράφουμε το όνομα παντού.
def font(size: int, bold: bool = False) -> tuple:
    return (_family, size, "bold") if bold else (_family, size)


def configure_row_tags(tree: ttk.Treeview) -> None:
    """Τα «tags» είναι ετικέτες που κολλάμε σε γραμμές του πίνακα για να πάρουν χρώμα.
    Π.χ. μια γραμμή με tag "green" βάφεται απαλό πράσινο (ιατρός με 3–4 ελεύθερες ώρες)."""
    tree.tag_configure("even", background=CARD)
    tree.tag_configure("odd", background=STRIPE)
    tree.tag_configure("green", background=SUCCESS_LIGHT)
    tree.tag_configure("yellow", background=WARNING_LIGHT)
    tree.tag_configure("red", background=DANGER_LIGHT)
    tree.tag_configure("muted", foreground=MUTED)
    tree.tag_configure("checked", background="#FAD4D4")
