"""Η οθόνη «Τα ραντεβού μου»: τα βλέπεις ανά εβδομάδα ή ανά μήνα και ακυρώνεις ένα ή πολλά μαζί.

Η ακύρωση πολλών δουλεύει έτσι: πατάς «Επιλογή πολλών για ακύρωση», εμφανίζεται μια στήλη με
κουτάκια, τσεκάρεις όσα θέλεις (μόνο ενεργά, μελλοντικά ραντεβού) και πατάς «Ακύρωση επιλεγμένων».
"""
import tkinter as tk
from datetime import date, timedelta
from tkinter import messagebox, ttk

from medapp.model.appointment import Appointment
from medapp.model.appointment_status import AppointmentStatus
from medapp.model.patient import Patient
from medapp.service.appointment_service import AppointmentService
from medapp.ui import theme, ui_support
from medapp.ui.widgets import Card, ChipButton, FlatButton, label
from medapp.util.date_utils import DateUtils


# Πάει n μήνες μπροστά/πίσω. Προσέχει τις μέρες που δεν υπάρχουν: 31 Ιανουαρίου + 1 μήνας
# δεν γίνεται 31 Φεβρουαρίου αλλά 28 (ή 29).
def _add_months(d: date, n: int) -> date:
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return date(y, m, min(d.day, DateUtils.last_day_of_month(y, m).day))


class MyAppointmentsPanel(tk.Frame):
    # Η πρώτη στήλη ("check") είναι τα κουτάκια. Φαίνεται μόνο στη λειτουργία πολλαπλής επιλογής.
    COLUMNS = (("check", "", 44), ("date", "Ημερομηνία", 130), ("time", "Ώρα", 60), ("doctor", "Ιατρός", 175),
               ("specialty", "Ειδικότητα", 130), ("area", "Περιοχή", 95), ("reason", "Λόγος", 260),
               ("status", "Κατάσταση", 110))

    def __init__(self, parent: tk.Misc, patient: Patient, service: AppointmentService):
        super().__init__(parent, bg=theme.BACKGROUND)
        self.patient = patient
        self.service = service
        self.reference = service.now().date()
        self.weekly = True
        self.show_cancelled = tk.BooleanVar(value=False)
        self.selection_mode = False
        # Τα τσεκαρισμένα ραντεβού, με κλειδί το id τους. Τα κρατάμε εδώ και όχι στον πίνακα,
        # για να μη χάνονται όταν πας σε άλλη εβδομάδα και ξαναγυρίσεις.
        self.checked: dict[int, Appointment] = {}
        self.rows: dict[str, Appointment] = {}

        # ---------- πάνω κάρτα: Εβδομάδα/Μήνας, ‹ Σήμερα ›, και πόσα ραντεβού έχει ----------
        top = Card(self)
        top.pack(fill="x")
        self.week_chip = ChipButton(top, "Εβδομάδα", lambda: self.set_weekly(True), selected=True)
        self.month_chip = ChipButton(top, "Μήνας", lambda: self.set_weekly(False))
        self.week_chip.pack(side="left")
        self.month_chip.pack(side="left", padx=(8, 22))
        FlatButton(top, "‹", FlatButton.SECONDARY, lambda: self.move(-1), size=13, padx=12, pady=3).pack(side="left")
        FlatButton(top, "Σήμερα", FlatButton.SECONDARY, self.go_today).pack(side="left", padx=6)
        FlatButton(top, "›", FlatButton.SECONDARY, lambda: self.move(1), size=13, padx=12, pady=3).pack(side="left")
        self.period_label = label(top, " ", 15, True)
        self.period_label.pack(side="left", padx=18)
        self.total_count = self._stat(top, "σύνολο περιόδου", theme.TEXT)
        self.active_count = self._stat(top, "ενεργά", theme.PRIMARY)

        # ---------- κάτω κάρτα: ο πίνακας και τα κουμπιά ακύρωσης ----------
        body = Card(self)
        body.pack(fill="both", expand=True, pady=(14, 0))
        head = tk.Frame(body, bg=theme.CARD)
        head.pack(fill="x", pady=(0, 10))
        label(head, "Τα ραντεβού μου", 13, True).pack(side="left")
        tk.Checkbutton(head, text="Εμφάνιση ακυρωμένων", variable=self.show_cancelled, command=self.refresh,
                       bg=theme.CARD, activebackground=theme.CARD, font=theme.font(10)).pack(side="right")

        self.bottom = tk.Frame(body, bg=theme.CARD)
        self.bottom.pack(side="bottom", fill="x", pady=(10, 0))
        # Δύο «μπάρες» κουμπιών που εναλλάσσονται: η κανονική και αυτή της πολλαπλής επιλογής.
        # κανονική λειτουργία
        self.normal_bar = tk.Frame(self.bottom, bg=theme.CARD)
        FlatButton(self.normal_bar, "Ακύρωση επιλεγμένου ραντεβού", FlatButton.DANGER,
                   self.cancel_selected).pack(side="right")
        FlatButton(self.normal_bar, "Επιλογή πολλών για ακύρωση", FlatButton.SECONDARY,
                   lambda: self.set_selection_mode(True)).pack(side="right", padx=10)
        # λειτουργία επιλογής: κουτάκια μόνο σε ραντεβού που μπορούν να ακυρωθούν
        self.select_bar = tk.Frame(self.bottom, bg=theme.CARD)
        self.selection_info = label(self.select_bar, " ", 10, fg=theme.MUTED)
        self.selection_info.pack(side="left")
        self.cancel_checked_button = FlatButton(self.select_bar, "Ακύρωση επιλεγμένων (0)", FlatButton.DANGER,
                                                self.cancel_checked)
        self.cancel_checked_button.pack(side="right")
        FlatButton(self.select_bar, "Άκυρο", FlatButton.SECONDARY,
                   lambda: self.set_selection_mode(False)).pack(side="right", padx=10)
        FlatButton(self.select_bar, "Επιλογή όλων της περιόδου", FlatButton.SECONDARY,
                   self.toggle_all_visible).pack(side="right")
        self.normal_bar.pack(fill="x")

        table = tk.Frame(body, bg=theme.CARD, highlightthickness=1, highlightbackground=theme.BORDER)
        table.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table, columns=[c[0] for c in self.COLUMNS], show="headings", selectmode="browse")
        for key, title, width in self.COLUMNS:
            self.tree.heading(key, text=title, anchor="w")
            self.tree.column(key, width=width, anchor="center" if key == "check" else "w",
                             stretch=key == "reason")
        # Στην αρχή κρύβουμε τη στήλη με τα κουτάκια (δείχνουμε όλες εκτός από την πρώτη).
        self.tree.configure(displaycolumns=[c[0] for c in self.COLUMNS[1:]])
        theme.configure_row_tags(self.tree)
        scroll = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.empty_label = label(table, "Δεν έχετε ραντεβού σε αυτή την περίοδο.", 11, fg=theme.MUTED)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<ButtonRelease-1>", self._on_click)
        self.refresh()

    # Ένα μεγάλο νούμερο με μικρή λεζάντα από κάτω (π.χ. «2 / ενεργά»). Γυρνάει το νούμερο,
    # για να το αλλάζουμε στο refresh.
    @staticmethod
    def _stat(parent: tk.Frame, caption: str, color: str) -> tk.Label:
        box = tk.Frame(parent, bg=theme.CARD)
        box.pack(side="right", padx=(18, 0))
        number = label(box, "0", 20, True, fg=color)
        number.pack(anchor="e")
        label(box, caption, 9, fg=theme.MUTED).pack(anchor="e")
        return number

    # ---------- περίοδος ----------

    def set_weekly(self, weekly: bool) -> None:
        self.weekly = weekly
        self.week_chip.set_selected(weekly)
        self.month_chip.set_selected(not weekly)
        self.refresh()

    # ‹ και ›: μία εβδομάδα ή έναν μήνα πίσω/μπροστά, ανάλογα με το τι βλέπουμε.
    def move(self, direction: int) -> None:
        self.reference = (self.reference + timedelta(weeks=direction) if self.weekly
                          else _add_months(self.reference, direction))
        self.refresh()

    def go_today(self) -> None:
        self.reference = self.service.now().date()
        self.refresh()

    def refresh(self) -> None:
        """Ξαναφέρνει τα ραντεβού της περιόδου από τη βάση και ξαναγεμίζει τον πίνακα.
        Την καλούμε μετά από κάθε αλλαγή: νέα κράτηση, ακύρωση, αλλαγή εβδομάδας κ.λπ."""
        if self.weekly:
            ok, items = ui_support.run(self, lambda: self.service.get_weekly_appointments(self.patient,
                                                                                         self.reference))
            self.period_label.configure(text=DateUtils.format_week(self.reference))
        else:
            ok, items = ui_support.run(self, lambda: self.service.get_monthly_appointments(
                self.patient, self.reference.year, self.reference.month))
            self.period_label.configure(text=DateUtils.format_month(self.reference.year, self.reference.month))
        now = self.service.now()
        # Τα ακυρωμένα τα κρύβουμε, εκτός αν έχει τσεκάρει «Εμφάνιση ακυρωμένων».
        shown = [a for a in items or [] if a.get_effective_status(now) != AppointmentStatus.CANCELLED
                 or self.show_cancelled.get()]
        active = sum(1 for a in items or [] if a.get_effective_status(now) == AppointmentStatus.ACTIVE)
        self.tree.delete(*self.tree.get_children())
        self.rows = {}
        for i, a in enumerate(shown):
            iid = str(a.id)
            self.rows[iid] = a
            self.tree.insert("", "end", iid=iid, values=self._values(a), tags=self._tags(a, i))
        self.active_count.configure(text=str(active))
        self.total_count.configure(text=str(len(shown)))
        if shown:
            self.empty_label.place_forget()
        else:
            self.empty_label.place(relx=0.5, rely=0.5, anchor="center")
            self.empty_label.lift()
        self._update_selection_bar()

    # Τι γράφει κάθε στήλη για ένα ραντεβού. Το ☑/☐ μπαίνει μόνο αν είμαστε σε πολλαπλή
    # επιλογή ΚΑΙ το ραντεβού μπορεί να ακυρωθεί. Στα υπόλοιπα η στήλη μένει κενή.
    def _values(self, a: Appointment) -> tuple:
        now = self.service.now()
        check = ""
        if self.selection_mode and a.is_cancellable(now):
            check = "☑" if a.id in self.checked else "☐"
        return (check, DateUtils.format_day_date(a.date), DateUtils.format_time(a.time), a.doctor.full_name,
                a.doctor.specialty, a.doctor.area, a.reason, a.get_effective_status(now).label)

    # Το χρώμα της γραμμής: κόκκινο αν είναι τσεκαρισμένο ή ακυρωμένο, γκρι γράμματα αν πέρασε,
    # αλλιώς εναλλάξ λευκό/γκρι για να διαβάζεται εύκολα.
    def _tags(self, a: Appointment, index: int) -> tuple:
        status = a.get_effective_status(self.service.now())
        if a.id in self.checked:
            return ("checked",)
        if status == AppointmentStatus.CANCELLED:
            return ("red", "muted")
        if status == AppointmentStatus.COMPLETED:
            return ("odd" if index % 2 else "even", "muted")
        return ("odd" if index % 2 else "even",)

    # ---------- πολλαπλή επιλογή για ακύρωση ----------

    # Μπαίνει/βγαίνει από τη λειτουργία με τα κουτάκια. Κάθε φορά ξεκινάμε με καθαρή επιλογή.
    def set_selection_mode(self, on: bool) -> None:
        self.selection_mode = on
        self.checked.clear()
        self.tree.configure(displaycolumns=[c[0] for c in (self.COLUMNS if on else self.COLUMNS[1:])])
        self.tree.selection_remove(*self.tree.selection())
        self.tree.configure(selectmode="none" if on else "browse")
        (self.normal_bar if on else self.select_bar).pack_forget()
        (self.select_bar if on else self.normal_bar).pack(fill="x")
        self.refresh()

    # Σε πολλαπλή επιλογή, κλικ οπουδήποτε στη γραμμή τσεκάρει/ξετσεκάρει (όχι μόνο στο κουτάκι).
    def _on_click(self, event: tk.Event) -> None:
        if not self.selection_mode:
            return
        iid = self.tree.identify_row(event.y)
        if iid:
            self.toggle(iid)

    def toggle(self, iid: str) -> None:
        """Αναποδογυρίζει το τσεκ μιας γραμμής. Τα ραντεβού που δεν ακυρώνονται (περασμένα ή
        ήδη ακυρωμένα) απλώς αγνοούν το κλικ."""
        a = self.rows[iid]
        if not a.is_cancellable(self.service.now()):
            return
        if self.checked.pop(a.id, None) is None:
            self.checked[a.id] = a
        self.refresh()

    def toggle_all_visible(self) -> None:
        """Το κουμπί «Επιλογή όλων της περιόδου». Αν δεν είναι όλα τσεκαρισμένα, τα τσεκάρει όλα·
        αν είναι ήδη όλα, τα ξετσεκάρει (πατάς δεύτερη φορά για να τα βγάλεις)."""
        now = self.service.now()
        cancellable = [a for a in self.rows.values() if a.is_cancellable(now)]
        all_checked = all(a.id in self.checked for a in cancellable)
        for a in cancellable:
            if all_checked:
                self.checked.pop(a.id, None)
            else:
                self.checked[a.id] = a
        self.refresh()

    # Ενημερώνει το «Ακύρωση επιλεγμένων (N)» και το κείμενο δίπλα. Με 0 επιλεγμένα το κουμπί γκριζάρει.
    def _update_selection_bar(self) -> None:
        n = len(self.checked)
        self.cancel_checked_button.configure(text=f"Ακύρωση επιλεγμένων ({n})")
        self.cancel_checked_button.set_enabled(n > 0)
        self.selection_info.configure(text="Πατήστε σε ενεργά ραντεβού για να τα τσεκάρετε." if n == 0
                                      else f"Επιλέχθηκαν {n} ραντεβού για ακύρωση.")

    # Ακύρωση όλων των τσεκαρισμένων. Δείχνουμε πρώτα λίστα με το τι θα ακυρωθεί και ζητάμε
    # επιβεβαίωση. Ο κανόνας «όλα ή κανένα» εφαρμόζεται στο AppointmentService.cancel_all.
    def cancel_checked(self) -> None:
        chosen = list(self.checked.values())
        if not chosen:
            return
        lines = "\n".join(f"• {DateUtils.format_day_date(a.date)} {DateUtils.format_time(a.time)} – "
                          f"{a.doctor.full_name}" for a in chosen)
        if not messagebox.askyesno("Επιβεβαίωση ακύρωσης", f"Θα ακυρωθούν {len(chosen)} ραντεβού:\n\n{lines}\n\n"
                                   "Η ενέργεια δεν αναιρείται. Συνέχεια;", icon="warning", parent=self):
            return
        ok, done = ui_support.run(self, lambda: self.service.cancel_all(self.patient, [a.id for a in chosen]))
        if ok:
            messagebox.showinfo("MedApp", f"Ακυρώθηκαν {done} ραντεβού.", parent=self)
            self.set_selection_mode(False)

    # Η απλή ακύρωση: ένα ραντεβού, αυτό που είναι επιλεγμένο στον πίνακα.
    def cancel_selected(self) -> None:
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("MedApp", "Επιλέξτε ένα ραντεβού από τον πίνακα ή πατήστε "
                                          "«Επιλογή πολλών για ακύρωση».", parent=self)
            return
        a = self.rows[selection[0]]
        if not messagebox.askyesno("Επιβεβαίωση ακύρωσης", f"Ακύρωση του ραντεβού με {a.doctor.full_name}\n"
                                   f"στις {DateUtils.format_day_date(a.date)} {DateUtils.format_time(a.time)};",
                                   parent=self):
            return
        ok, _ = ui_support.run(self, lambda: self.service.cancel(self.patient, a.id))
        if ok:
            messagebox.showinfo("MedApp", "Το ραντεβού ακυρώθηκε.", parent=self)
            self.refresh()
