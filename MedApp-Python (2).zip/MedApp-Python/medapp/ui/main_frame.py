"""Το κύριο παράθυρο της εφαρμογής. Δεν δείχνει κάτι δικό του, απλώς αλλάζει οθόνες:
σύνδεση → εγγραφή → αρχική ασθενή → πίσω στη σύνδεση με την αποσύνδεση."""
import tkinter as tk

from medapp.model.patient import Patient
from medapp.service.appointment_service import AppointmentService
from medapp.service.auth_service import AuthService
from medapp.service.doctor_service import DoctorService
from medapp.ui import theme
from medapp.ui.login_panel import LoginPanel
from medapp.ui.patient_home_panel import PatientHomePanel
from medapp.ui.register_panel import RegisterPanel


class MainFrame(tk.Tk):
    def __init__(self, auth_service: AuthService, doctor_service: DoctorService,
                 appointment_service: AppointmentService):
        super().__init__()
        theme.install(self)          # πρώτα το θέμα, πριν φτιαχτεί οποιοδήποτε κουμπί
        self.title("MedApp – Ραντεβού με Ιατρούς")
        self.geometry("1180x760")
        self.minsize(1000, 680)
        self.doctor_service = doctor_service
        self.appointment_service = appointment_service
        # Σύνδεση και εγγραφή τις φτιάχνουμε μία φορά και απλώς τις κρύβουμε/δείχνουμε.
        # Η αρχική οθόνη φτιάχνεται από την αρχή σε κάθε σύνδεση, γιατί εξαρτάται από τον ασθενή.
        self.login_panel = LoginPanel(self, self, auth_service)
        self.register_panel = RegisterPanel(self, self, auth_service)
        self.home_panel: PatientHomePanel | None = None
        self.current: tk.Frame | None = None
        self.show_login()

    # Κρύβει την οθόνη που φαίνεται τώρα (pack_forget) και δείχνει τη νέα.
    def _show(self, panel: tk.Frame) -> None:
        if self.current is not None:
            self.current.pack_forget()
        panel.pack(fill="both", expand=True)
        self.current = panel

    def show_login(self) -> None:
        self.login_panel.reset()
        self._show(self.login_panel)

    def show_register(self) -> None:
        self.register_panel.reset()
        self._show(self.register_panel)

    def show_home(self, patient: Patient) -> None:
        """Μετά από επιτυχή σύνδεση ή εγγραφή. Αν υπήρχε παλιά αρχική οθόνη (άλλου χρήστη),
        τη σβήνουμε πρώτα."""
        if self.home_panel is not None:
            self.home_panel.destroy()
        self.home_panel = PatientHomePanel(self, self, patient, self.doctor_service, self.appointment_service)
        self._show(self.home_panel)

    # Αποσύνδεση: πετάμε την αρχική οθόνη (μαζί με ό,τι στοιχεία ασθενή είχε) και πάμε στη σύνδεση.
    def logout(self) -> None:
        if self.home_panel is not None:
            self.home_panel.destroy()
            self.home_panel = None
            self.current = None
        self.show_login()
