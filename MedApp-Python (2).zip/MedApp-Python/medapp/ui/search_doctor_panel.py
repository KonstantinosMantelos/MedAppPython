"""Η οθόνη «Νέο ραντεβού»: διαλέγεις ειδικότητα, περιοχές και ημερομηνία, και βλέπεις
ποιοι ιατροί δέχονται εκείνη τη μέρα, με τις ελεύθερες ώρες τους και ένα χρώμα
(πράσινο / κίτρινο / κόκκινο) για να καταλαβαίνεις με μια ματιά πού υπάρχει θέση.

Κάθε αλλαγή φίλτρου ξανατρέχει την αναζήτηση αμέσως, δεν υπάρχει κουμπί «Αναζήτηση».
"""
import tkinter as tk
from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from tkinter import messagebox, ttk

from medapp.model.availability_level import AvailabilityLevel
from medapp.model.doctor import Doctor
from medapp.model.patient import Patient
from medapp.model.time_slot import TimeSlot
from medapp.service.appointment_service import AppointmentService
from medapp.service.doctor_service import DoctorService
from medapp.ui import theme, ui_support
from medapp.ui.booking_dialog import BookingDialog
from medapp.ui.date_picker import DatePicker
from medapp.ui.widgets import Card, ChipButton, FlatButton, LinkLabel, Pill, label
from medapp.util.date_utils import DateUtils

# Ποιο tag χρώματος (δες theme.configure_row_tags) παίρνει η γραμμή για κάθε επίπεδο.
LEVEL_TAG = {AvailabilityLevel.AVAILABLE: "green", AvailabilityLevel.PARTIAL: "yellow", AvailabilityLevel.NONE: "red"}


@dataclass
class DoctorRow:
    """Μια γραμμή του πίνακα: ο ιατρός, οι ελεύθερες ώρες του εκείνη τη μέρα, το χρώμα, και
    (αν είναι γεμάτος) πότε είναι το επόμενο ελεύθερο ραντεβού του."""
    doctor: Doctor
    free: list[TimeSlot]
    level: AvailabilityLevel
    next_other_day: TimeSlot | None

    # Το κείμενο της στήλης «Ελεύθερες ώρες»: π.χ. "09:00  ·  12:00" ή "Πλήρες · επόμενο: ...".
    def slots_text(self) -> str:
        if self.free:
            return "  ·  ".join(DateUtils.format_time(s.time) for s in self.free)
        if self.next_other_day:
            n = self.next_other_day
            return f"Πλήρες · επόμενο: {DateUtils.format_day_date(n.date)} {DateUtils.format_time(n.time)}"
        return "Πλήρες"


class SearchDoctorPanel(tk.Frame):
    COLUMNS = (("name", "Ονοματεπώνυμο", 190), ("area", "Περιοχή", 105), ("address", "Διεύθυνση", 175),
               ("slots", "Ελεύθερες ώρες", 300), ("level", "Διαθεσιμότητα", 170))

    def __init__(self, parent: tk.Misc, patient: Patient, doctor_service: DoctorService,
                 appointment_service: AppointmentService, on_booked: Callable[[], None]):
        super().__init__(parent, bg=theme.BACKGROUND)
        self.patient = patient
        self.doctor_service = doctor_service
        self.appointment_service = appointment_service
        self.on_booked = on_booked
        self.area_buttons: list[ChipButton] = []
        self.rows: dict[str, DoctorRow] = {}

        # ---------- πάνω κάρτα: τα φίλτρα ----------
        filters = Card(self)
        filters.pack(fill="x")
        label(filters, "Βρείτε ιατρό", 17, True).pack(anchor="w")
        label(filters, "Επιλέξτε ειδικότητα, μία ή περισσότερες περιοχές και ημερομηνία· "
                       "τα αποτελέσματα ενημερώνονται αμέσως.", 10, fg=theme.MUTED).pack(anchor="w", pady=(2, 12))
        row = tk.Frame(filters, bg=theme.CARD)
        row.pack(fill="x")
        spec = tk.Frame(row, bg=theme.CARD)
        spec.pack(side="left", anchor="n", padx=(0, 24))
        label(spec, "Ειδικότητα", 10, True, fg=theme.MUTED).pack(anchor="w")
        # readonly = διαλέγεις μόνο από τη λίστα, δεν γράφεις ό,τι θέλεις.
        self.specialty_box = ttk.Combobox(spec, state="readonly", width=24, font=theme.font(11))
        self.specialty_box.pack(anchor="w", pady=(4, 0))
        areas = tk.Frame(row, bg=theme.CARD)
        areas.pack(side="left", fill="x", expand=True)
        head = tk.Frame(areas, bg=theme.CARD)
        head.pack(anchor="w")
        label(head, "Περιοχές (πατήστε όσες θέλετε)", 10, True, fg=theme.MUTED).pack(side="left")
        LinkLabel(head, "Όλες", lambda: self.set_all_areas(True)).pack(side="left", padx=(12, 0))
        label(head, " · ", 10, fg=theme.MUTED).pack(side="left")
        LinkLabel(head, "Καμία", lambda: self.set_all_areas(False)).pack(side="left")
        self.area_chips = tk.Frame(areas, bg=theme.CARD)
        self.area_chips.pack(anchor="w", pady=(4, 0))

        label(filters, "Ημερομηνία", 10, True, fg=theme.MUTED).pack(anchor="w", pady=(14, 4))
        date_row = tk.Frame(filters, bg=theme.CARD)
        date_row.pack(anchor="w")
        # Η ημερομηνία ξεκινάει από σήμερα και πάει μέχρι 30 μέρες μπροστά.
        today = appointment_service.now().date()
        self.date_picker = DatePicker(date_row, today, today,
                                      today + timedelta(days=AppointmentService.BOOKING_HORIZON_DAYS))
        self.date_picker.pack(side="left")
        for text, fg, bg in (("3–4 ελεύθερα", theme.SUCCESS, theme.SUCCESS_LIGHT),
                             ("1–2 ελεύθερα", theme.WARNING, theme.WARNING_LIGHT),
                             ("κανένα", theme.DANGER, theme.DANGER_LIGHT)):
            Pill(date_row, text, fg, bg).pack(side="left", padx=(12, 0))

        # ---------- κάτω κάρτα: ο πίνακας με τους ιατρούς ----------
        results = Card(self)
        results.pack(fill="both", expand=True, pady=(14, 0))
        head = tk.Frame(results, bg=theme.CARD)
        head.pack(fill="x", pady=(0, 10))
        self.list_title = label(head, " ", 13, True)
        self.list_title.pack(side="left")
        self.result_label = label(head, " ", 10, fg=theme.MUTED)
        self.result_label.pack(side="right")

        bottom = tk.Frame(results, bg=theme.CARD)
        bottom.pack(side="bottom", fill="x", pady=(10, 0))
        label(bottom, "Διπλό κλικ σε ιατρό ανοίγει την κράτηση για την ημέρα που επιλέξατε", 9,
              fg=theme.MUTED).pack(side="left")
        FlatButton(bottom, "Κράτηση ραντεβού  →", FlatButton.PRIMARY, self.open_booking).pack(side="right")

        self.table_area = tk.Frame(results, bg=theme.CARD, highlightthickness=1, highlightbackground=theme.BORDER)
        self.table_area.pack(fill="both", expand=True)
        # Το Treeview είναι ο «πίνακας» του Tkinter. Με show="headings" κρύβουμε την πρώτη
        # στήλη-δέντρο που έχει από μόνο του, και κρατάμε μόνο τις δικές μας στήλες.
        self.tree = ttk.Treeview(self.table_area, columns=[c[0] for c in self.COLUMNS], show="headings",
                                 selectmode="browse")
        for key, title, width in self.COLUMNS:
            self.tree.heading(key, text=title, anchor="w")
            self.tree.column(key, width=width, anchor="w", stretch=key in ("slots", "address"))
        theme.configure_row_tags(self.tree)
        scroll = ttk.Scrollbar(self.table_area, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.empty_label = label(self.table_area, "", 11, fg=theme.MUTED)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", lambda e: self.open_booking())

        # Γεμίζουμε τις ειδικότητες, διαλέγουμε την πρώτη και φορτώνουμε τις περιοχές της.
        ok, specialties = ui_support.run(self, doctor_service.get_specialties)
        self.specialty_box.configure(values=specialties or [])
        if specialties:
            self.specialty_box.current(0)
        self.specialty_box.bind("<<ComboboxSelected>>", lambda e: self.load_areas())
        self.date_picker.add_date_listener(lambda d: self.search())
        self.load_areas()

    # ---------- φίλτρα ----------

    def load_areas(self) -> None:
        """Άλλαξε η ειδικότητα: σβήνουμε τα παλιά κουμπάκια περιοχών και φτιάχνουμε καινούργια,
        όλα πατημένα, ώστε να βλέπει αμέσως όλους τους ιατρούς της ειδικότητας."""
        for chip in self.area_buttons:
            chip.destroy()
        self.area_buttons = []
        specialty = self.specialty_box.get()
        if specialty:
            ok, areas = ui_support.run(self, lambda: self.doctor_service.get_areas(specialty))
            for area in areas or []:
                chip = ChipButton(self.area_chips, area, selected=True)
                # Πάλι το κόλπο c=chip, για να ξέρει κάθε κουμπάκι τον εαυτό του.
                chip.command = lambda c=chip: self._toggle_area(c)
                chip.pack(side="left", padx=(0, 8))
                self.area_buttons.append(chip)
        self.search()

    def _toggle_area(self, chip: ChipButton) -> None:
        chip.set_selected(not chip.selected)
        self.search()

    def set_all_areas(self, selected: bool) -> None:
        for chip in self.area_buttons:
            chip.set_selected(selected)
        self.search()

    def selected_areas(self) -> list[str]:
        return [str(c.cget("text")) for c in self.area_buttons if c.selected]

    # ---------- αναζήτηση ----------

    # Η κύρια δουλειά της οθόνης. Τρέχει σε κάθε αλλαγή φίλτρου και ξαναγεμίζει τον πίνακα.
    def search(self) -> None:
        specialty = self.specialty_box.get()
        areas = self.selected_areas()
        day = self.date_picker.get_date()
        rows: list[DoctorRow] = []
        not_working = 0
        if specialty and areas:
            ok, doctors = ui_support.run(self, lambda: self.doctor_service.find_doctors(specialty, areas))
            for d in doctors or []:
                # Όσοι δεν δουλεύουν εκείνη τη μέρα δεν μπαίνουν στον πίνακα. Τους μετράμε μόνο,
                # για να γράψουμε «Χ δεν δέχονται αυτή την ημέρα».
                if not self.appointment_service.is_working_day(d, day):
                    not_working += 1
                    continue
                free = self.appointment_service.get_available_slots(d, day)
                # Μόνο για τους γεμάτους ψάχνουμε το επόμενο ελεύθερο (σε επόμενη μέρα).
                nxt = None if free else self.appointment_service.find_next_available(d, day + timedelta(days=1))
                rows.append(DoctorRow(d, free, AppointmentService.classify(len(free)), nxt))
        rows.sort(key=lambda r: len(r.free), reverse=True)      # πρώτα όσοι έχουν περισσότερες ελεύθερες ώρες

        # Αδειάζουμε τον πίνακα και τον ξαναγεμίζουμε. Ως iid (το «κλειδί» κάθε γραμμής)
        # βάζουμε τον ΑΜΚΑ του ιατρού, για να τον βρίσκουμε μετά στο κλικ.
        self.tree.delete(*self.tree.get_children())
        self.rows = {}
        for r in rows:
            iid = r.doctor.amka
            self.rows[iid] = r
            self.tree.insert("", "end", iid=iid, tags=(LEVEL_TAG[r.level],), values=(
                r.doctor.full_name, r.doctor.area, r.doctor.address, r.slots_text(), r.level.label))
        self.list_title.configure(text=f"Διαθεσιμότητα για {DateUtils.format_day_date(day)}")
        n = len(rows)
        text = "1 ιατρός δέχεται" if n == 1 else f"{n} ιατροί δέχονται"
        if not_working:
            text += f" · {not_working} δεν δέχονται αυτή την ημέρα"
        self.result_label.configure(text=text)
        # Αν δεν βγήκε κανείς, δείχνουμε ένα μήνυμα στη μέση του πίνακα αντί για άδειο κουτί.
        if n == 0:
            self.empty_label.configure(text="Επιλέξτε τουλάχιστον μία περιοχή." if not areas else
                                       "Κανένας ιατρός δεν δέχεται αυτή την ημέρα στις επιλεγμένες περιοχές. "
                                       "Δοκιμάστε άλλη ημερομηνία.")
            self.empty_label.place(relx=0.5, rely=0.55, anchor="center")
            self.empty_label.lift()
        else:
            self.empty_label.place_forget()
            first = self.tree.get_children()[0]
            self.tree.selection_set(first)
            self.tree.focus(first)

    # Ανοίγει το παράθυρο κράτησης για τον ιατρό που είναι επιλεγμένος, στη μέρα που έχει
    # διαλέξει ο ασθενής. Αν κλείσει ραντεβού, ανανεώνουμε και τα δύο πάνελ.
    def open_booking(self) -> None:
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("MedApp", "Επιλέξτε πρώτα έναν ιατρό από τη λίστα.", parent=self)
            return
        doctor = self.rows[selection[0]].doctor
        dialog = BookingDialog(self.winfo_toplevel(), self.patient, doctor, self.appointment_service,
                               self.doctor_service, self.date_picker.get_date())
        if dialog.show():
            self.on_booked()
            self.search()
