"""Εγγραφή και σύνδεση ασθενών. Όλοι οι έλεγχοι της φόρμας εγγραφής γίνονται εδώ, όχι στην οθόνη."""
import re
from collections.abc import Callable
from datetime import datetime

from medapp.dao.patient_dao import PatientDAO
from medapp.model.patient import Patient
from medapp.service.validation_error import ValidationError
from medapp.util.amka_validator import AmkaValidator
from medapp.util.password_hasher import PasswordHasher


class AuthService:
    MIN_PASSWORD_LENGTH = 6

    # Το clock είναι μια συνάρτηση που μας δίνει το «τώρα». Κανονικά είναι το datetime.now,
    # αλλά στα tests περνάμε μια σταθερή ώρα, για να βγαίνουν πάντα τα ίδια αποτελέσματα.
    def __init__(self, patient_dao: PatientDAO, clock: Callable[[], datetime] = datetime.now):
        self.patient_dao = patient_dao
        self.clock = clock

    def register(self, amka: str, first_name: str, last_name: str, phone: str, email: str,
                 password: str, confirm_password: str) -> Patient:
        # Πρώτα καθαρίζουμε κενά στην αρχή/στο τέλος (συμβαίνει συχνά με copy-paste).
        amka, first_name, last_name = _trim(amka), _trim(first_name), _trim(last_name)
        phone, email = _trim(phone), _trim(email)
        if not AmkaValidator.is_valid(amka):
            raise ValidationError("Ο ΑΜΚΑ δεν είναι έγκυρος (11 ψηφία με σωστό ψηφίο ελέγχου).")
        if not first_name or not last_name:
            raise ValidationError("Συμπληρώστε όνομα και επώνυμο.")
        # Τηλέφωνο και email είναι προαιρετικά. Τα ελέγχουμε μόνο αν τα συμπλήρωσε.
        if phone and not re.fullmatch(r"\d{10}", phone):
            raise ValidationError("Το τηλέφωνο πρέπει να έχει 10 ψηφία.")
        if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise ValidationError("Το email δεν είναι έγκυρο.")
        if password is None or len(password) < self.MIN_PASSWORD_LENGTH:
            raise ValidationError(f"Ο κωδικός πρέπει να έχει τουλάχιστον {self.MIN_PASSWORD_LENGTH} χαρακτήρες.")
        if password != confirm_password:
            raise ValidationError("Οι κωδικοί δεν ταιριάζουν.")
        # Αυτόν τον έλεγχο τον αφήνουμε τελευταίο, γιατί είναι ο μόνος που πάει στη βάση.
        if self.patient_dao.exists(amka):
            raise ValidationError("Υπάρχει ήδη λογαριασμός με αυτόν τον ΑΜΚΑ.")
        # Όλα εντάξει: φτιάχνουμε salt και hash και αποθηκεύουμε. Τον ίδιο τον κωδικό τον
        # ξεχνάμε εδώ, δεν πάει πουθενά.
        salt = PasswordHasher.new_salt()
        patient = Patient(amka, first_name, last_name, phone, email,
                          PasswordHasher.hash(password, salt), salt, self.clock())
        self.patient_dao.insert(patient)
        return patient

    def login(self, amka: str, password: str) -> Patient:
        # Επίτηδες βγάζουμε το ίδιο μήνυμα είτε δεν υπάρχει ο ΑΜΚΑ είτε είναι λάθος ο κωδικός,
        # για να μην μπορεί κάποιος να «ψαρέψει» ποιοι ΑΜΚΑ έχουν λογαριασμό.
        found = self.patient_dao.find_by_amka(_trim(amka))
        if found is None or password is None or not PasswordHasher.verify(password, found.salt, found.password_hash):
            raise ValidationError("Λάθος ΑΜΚΑ ή κωδικός.")
        return found


# Το None το κάνουμε κενό κείμενο, για να μη σκάει το .strip().
def _trim(s: str | None) -> str:
    return "" if s is None else s.strip()
