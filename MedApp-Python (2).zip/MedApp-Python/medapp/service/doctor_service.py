"""Ό,τι αφορά τους ιατρούς: ειδικότητες, περιοχές, αναζήτηση και λόγοι επίσκεψης."""
from medapp.dao.doctor_dao import DoctorDAO
from medapp.dao.visit_reason_dao import VisitReasonDAO
from medapp.model.doctor import Doctor
from medapp.service.validation_error import ValidationError
from medapp.util.date_utils import DateUtils


class DoctorService:
    # Η επιλογή «Άλλο». Την κρατάμε σε σταθερά, για να μη γράφουμε το "Άλλο" σε δέκα σημεία
    # και κάποια στιγμή να το γράψουμε λάθος σε ένα από αυτά.
    OTHER_REASON = "Άλλο"

    def __init__(self, doctor_dao: DoctorDAO, visit_reason_dao: VisitReasonDAO):
        self.doctor_dao = doctor_dao
        self.visit_reason_dao = visit_reason_dao

    # Ταξινόμηση με το δικό μας κλειδί, για να πηγαίνουν σωστά τα ελληνικά με τους τόνους.
    def get_specialties(self) -> list[str]:
        return sorted(self.doctor_dao.find_all_specialties(), key=DateUtils.greek_sort_key)

    def get_areas(self, specialty: str) -> list[str]:
        return sorted(self.doctor_dao.find_areas_by_specialty(specialty), key=DateUtils.greek_sort_key)

    def find_doctors(self, specialty: str | None, areas: list[str] | None) -> list[Doctor]:
        """Ιατροί της ειδικότητας σε όλες τις επιλεγμένες περιοχές μαζί.
        Αν δεν έχει διαλέξει ειδικότητα ή περιοχή, του το λέμε με φιλικό μήνυμα."""
        if specialty is None:
            raise ValidationError("Επιλέξτε ειδικότητα.")
        if not areas:
            raise ValidationError("Επιλέξτε τουλάχιστον μία περιοχή.")
        return self.doctor_dao.find_by_specialty_and_areas(specialty, areas)

    def get_visit_reasons(self, doctor: Doctor) -> list[str]:
        """Οι 3 έτοιμοι λόγοι του ιατρού από τη βάση, και στο τέλος προσθέτουμε το «Άλλο»."""
        return [*self.visit_reason_dao.find_by_doctor(doctor.amka), self.OTHER_REASON]

    def resolve_reason(self, selected_option: str | None, other_text: str | None) -> str:
        """Αποφασίζει τι λόγο θα γράψουμε τελικά στο ραντεβού.

        Αν διάλεξε έτοιμο λόγο, κρατάμε αυτόν (και αγνοούμε το κουτάκι κειμένου). Αν διάλεξε
        «Άλλο», παίρνουμε ό,τι έγραψε, αρκεί να μην είναι κενό.
        """
        if selected_option is None:
            raise ValidationError("Επιλέξτε λόγο επίσκεψης.")
        if selected_option == self.OTHER_REASON:
            text = (other_text or "").strip()
            if not text:
                raise ValidationError("Γράψτε τον λόγο της επίσκεψης στο πεδίο «Άλλο».")
            return text
        return selected_option
