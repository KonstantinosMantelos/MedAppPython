"""Η «καρδιά» της εφαρμογής: ελεύθερες ώρες, κράτηση, ακύρωση και προβολή ραντεβού.

Όλοι οι κανόνες για τα ραντεβού είναι μαζεμένοι εδώ. Οι οθόνες απλώς καλούν αυτές τις
μεθόδους, και αν κάτι δεν επιτρέπεται παίρνουν πίσω ένα ValidationError με το μήνυμα.
"""
from collections.abc import Callable
from datetime import date, datetime, time, timedelta

from medapp.dao.appointment_dao import AppointmentDAO
from medapp.dao.database import DataAccessError
from medapp.dao.working_hours_dao import WorkingHoursDAO
from medapp.model.appointment import Appointment
from medapp.model.appointment_status import AppointmentStatus
from medapp.model.availability_level import AvailabilityLevel
from medapp.model.doctor import Doctor
from medapp.model.patient import Patient
from medapp.model.time_slot import TimeSlot
from medapp.model.working_hours import WorkingHours
from medapp.service.validation_error import ValidationError
from medapp.util.date_utils import DateUtils


class AppointmentService:
    # Οι βασικοί αριθμοί της εφαρμογής, όλοι μαζεμένοι εδώ. Αν θέλεις να αλλάξεις κάποιον
    # κανόνα (π.χ. 5 ραντεβού τη μέρα), τον αλλάζεις σε ένα σημείο και τελείωσες.
    BOOKING_HORIZON_DAYS = 30
    """Πόσες μέρες μπροστά μπορεί να κλειστεί ραντεβού."""
    MAX_REASON_LENGTH = 255
    MAX_APPOINTMENT_MINUTES = 90
    """Κάθε ραντεβού (εξέταση + διάλειμμα) «κλειδώνει» τον ιατρό για 1,5 ώρα από την έναρξή του."""
    MAX_APPOINTMENTS_PER_DAY = 4
    """Μέγιστος αριθμός ενεργών ραντεβού ενός ιατρού την ίδια ημέρα."""
    GOOD_FREE_PER_DAY = 3
    """Πράσινο: τουλάχιστον τόσα ελεύθερα ραντεβού την ημέρα (3–4 από τα 4)."""

    def __init__(self, appointment_dao: AppointmentDAO, working_hours_dao: WorkingHoursDAO,
                 clock: Callable[[], datetime] = datetime.now):
        self.appointment_dao = appointment_dao
        self.working_hours_dao = working_hours_dao
        self.clock = clock

    # Χωρίς μικροδευτερόλεπτα, για να συγκρίνονται καθαρά οι ώρες.
    def now(self) -> datetime:
        return self.clock().replace(microsecond=0)

    # ---------- διαθεσιμότητα: ποιες ώρες είναι ελεύθερες ----------

    def get_slots(self, doctor: Doctor, day: date) -> list[TimeSlot]:
        """Όλες οι χρονοθυρίδες του ιατρού μια ημέρα, σημειωμένες ως ελεύθερες ή κλεισμένες."""
        return self._build_slots(self.working_hours_dao.find_by_doctor(doctor.amka), doctor, day)

    def get_available_slots(self, doctor: Doctor, day: date) -> list[TimeSlot]:
        """Μόνο οι ελεύθερες χρονοθυρίδες μιας ημέρας."""
        return [s for s in self.get_slots(doctor, day) if s.available]

    def get_availability_overview(self, doctor: Doctor, days: int) -> dict[date, int]:
        """Για κάθε μέρα που δουλεύει ο ιατρός τις επόμενες `days` μέρες: πόσα ελεύθερα ραντεβού
        έχει. Από εδώ γεμίζει η λίστα ημερών στο παράθυρο κράτησης."""
        # Το ωράριο το φέρνουμε μία φορά απ' έξω, για να μην πηγαίνουμε στη βάση 31 φορές.
        hours = self.working_hours_dao.find_by_doctor(doctor.amka)
        today = self.now().date()
        overview: dict[date, int] = {}
        for i in range(days):
            day = today + timedelta(days=i)
            if _hours_for(hours, day):
                overview[day] = sum(1 for s in self._build_slots(hours, doctor, day) if s.available)
        return overview

    def find_next_available(self, doctor: Doctor, from_date: date | None = None) -> TimeSlot | None:
        """Η πρώτη ελεύθερη ώρα από τη μέρα `from_date` και μετά. Τη δείχνουμε όταν ένας ιατρός
        είναι γεμάτος τη μέρα που ζήτησε ο ασθενής («Πλήρες · επόμενο: Παρ 13/11 09:00»)."""
        hours = self.working_hours_dao.find_by_doctor(doctor.amka)
        today = self.now().date()
        last = today + timedelta(days=self.BOOKING_HORIZON_DAYS)
        # Δεν ψάχνουμε ποτέ στο παρελθόν ούτε πέρα από τις 30 μέρες.
        day = today if from_date is None or from_date < today else from_date
        while day <= last:
            if _hours_for(hours, day):
                for s in self._build_slots(hours, doctor, day):
                    if s.available:
                        return s
            day += timedelta(days=1)
        return None

    def is_working_day(self, doctor: Doctor, day: date) -> bool:
        """Αν ο ιατρός δέχεται καθόλου εκείνη τη μέρα. Μετράμε όλες τις ώρες του ωραρίου,
        ακόμα και τις πιασμένες: αν έχει ωράριο, δουλεύει, απλώς μπορεί να είναι γεμάτος."""
        return bool(self.get_slots(doctor, day))

    def get_availability_level(self, doctor: Doctor, day: date) -> AvailabilityLevel:
        """Επίπεδο διαθεσιμότητας του ιατρού για μία συγκεκριμένη ημέρα."""
        return self.classify(len(self.get_available_slots(doctor, day)))

    @classmethod
    def classify(cls, free_slots_that_day: int) -> AvailabilityLevel:
        """Ο κανόνας των χρωμάτων για μία μέρα: 3–4 ελεύθερα → πράσινο, 1–2 → κίτρινο,
        0 → κόκκινο. Είναι classmethod γιατί δεν χρειάζεται βάση, μόνο τον αριθμό."""
        if free_slots_that_day <= 0:
            return AvailabilityLevel.NONE
        if free_slots_that_day >= cls.GOOD_FREE_PER_DAY:
            return AvailabilityLevel.AVAILABLE
        return AvailabilityLevel.PARTIAL

    @classmethod
    def overlaps(cls, a: time, b: time) -> bool:
        """Συγκρούονται δύο ραντεβού; Ναι, αν απέχουν λιγότερο από 90 λεπτά. Π.χ. 09:00 και 10:00
        συγκρούονται, ενώ 09:00 και 10:30 όχι (ακριβώς 1,5 ώρα είναι οκ)."""
        # Τα κάνουμε λεπτά από τα μεσάνυχτα, γιατί το time της Python δεν κάνει αφαιρέσεις.
        minutes = abs((a.hour * 60 + a.minute) - (b.hour * 60 + b.minute))
        return minutes < cls.MAX_APPOINTMENT_MINUTES

    # ---------- κράτηση / ακύρωση ----------
    # Η σειρά των ελέγχων στο book() έχει σημασία: πρώτα τα φθηνά (κείμενο, ώρα) και μετά
    # όσα θέλουν βάση. Αν κάτι αποτύχει, σταματάμε με μήνυμα που λέει ακριβώς τι φταίει.

    def book(self, patient: Patient, doctor: Doctor, day: date, at: time, reason: str | None) -> Appointment:
        r = (reason or "").strip()
        if not r:
            raise ValidationError("Συμπληρώστε τον λόγο του ραντεβού.")
        if len(r) > self.MAX_REASON_LENGTH:
            raise ValidationError(f"Ο λόγος δεν μπορεί να ξεπερνά τους {self.MAX_REASON_LENGTH} χαρακτήρες.")
        if datetime.combine(day, at) <= self.now():
            raise ValidationError("Δεν μπορείτε να κλείσετε ραντεβού σε παρελθοντική ώρα.")
        if day > self.now().date() + timedelta(days=self.BOOKING_HORIZON_DAYS):
            raise ValidationError(f"Τα ραντεβού κλείνονται έως {self.BOOKING_HORIZON_DAYS} ημέρες μπροστά.")
        # Όριο 4 ραντεβού τη μέρα για κάθε ιατρό.
        if len(self.appointment_dao.find_booked_times(doctor.amka, day)) >= self.MAX_APPOINTMENTS_PER_DAY:
            raise ValidationError(f"Ο ιατρός έχει ήδη {self.MAX_APPOINTMENTS_PER_DAY} ραντεβού αυτή την ημέρα "
                                  "(το μέγιστο). Διαλέξτε άλλη ημέρα.")
        # Υπάρχει αυτή η ώρα στο ωράριό του; (π.χ. το 09:10 δεν υπάρχει, μόνο 09:00, 10:30...)
        slot = next((s for s in self.get_slots(doctor, day) if s.time == at), None)
        if slot is None:
            raise ValidationError("Η ώρα αυτή δεν ανήκει στο ωράριο του ιατρού.")
        if not slot.available:
            raise ValidationError(f"Η ώρα {DateUtils.format_time(at)} δεν είναι διαθέσιμη: "
                                  "κάθε ραντεβού δεσμεύει τον ιατρό έως 1,5 ώρα. Διαλέξτε άλλη.")
        # Ο ίδιος ασθενής δεν μπορεί να είναι σε δύο ραντεβού την ίδια στιγμή.
        if self._overlaps_any(at, self.appointment_dao.find_patient_booked_times(patient.amka, day)):
            raise ValidationError("Έχετε ήδη άλλο ραντεβού σε απόσταση μικρότερη από 1,5 ώρα.")
        appointment = Appointment(0, patient.amka, doctor, day, at, r, AppointmentStatus.ACTIVE, self.now())
        try:
            self.appointment_dao.insert(appointment)
        except DataAccessError:
            # Δίχτυ ασφαλείας: αν δύο άτομα πατήσουν «Κράτηση» την ίδια ακριβώς στιγμή, η βάση
            # (με το μοναδικό ευρετήριο ux_doctor_slot) αφήνει να περάσει μόνο το ένα.
            raise ValidationError("Η κράτηση δεν ολοκληρώθηκε: η ώρα δεν είναι πια διαθέσιμη.") from None
        return appointment

    def cancel(self, patient: Patient, appointment_id: int) -> None:
        # Τρεις έλεγχοι πριν ακυρώσουμε: υπάρχει, είναι δικό του, και μπορεί να ακυρωθεί.
        a = self.appointment_dao.find_by_id(appointment_id)
        if a is None:
            raise ValidationError("Το ραντεβού δεν βρέθηκε.")
        if a.patient_amka != patient.amka:
            raise ValidationError("Μπορείτε να ακυρώσετε μόνο δικά σας ραντεβού.")
        if not a.is_cancellable(self.now()):
            raise ValidationError(f"Το ραντεβού είναι {a.get_effective_status(self.now()).label.lower()} "
                                  "και δεν μπορεί να ακυρωθεί.")
        a.cancel()
        self.appointment_dao.update_status(a.id, a.status)

    def cancel_all(self, patient: Patient, appointment_ids: list[int]) -> int:
        """Ακύρωση πολλών μαζί, με τον κανόνα «όλα ή κανένα».

        Πρώτα ελέγχουμε ΟΛΑ τα ραντεβού. Αν έστω και ένα δεν μπορεί να ακυρωθεί, σταματάμε
        χωρίς να έχουμε πειράξει τίποτα. Μόνο αν περάσουν όλα, τα ακυρώνουμε. Έτσι ο χρήστης
        δεν μένει με μισή δουλειά. Γυρνάει πόσα ακυρώθηκαν.
        """
        if not appointment_ids:
            raise ValidationError("Επιλέξτε τουλάχιστον ένα ραντεβού για ακύρωση.")
        to_cancel: list[Appointment] = []
        # Το dict.fromkeys είναι ένα κόλπο για να βγάλουμε τα διπλά και να κρατήσουμε τη σειρά.
        for appointment_id in dict.fromkeys(appointment_ids):
            a = self.appointment_dao.find_by_id(appointment_id)
            if a is None:
                raise ValidationError(f"Το ραντεβού {appointment_id} δεν βρέθηκε.")
            if a.patient_amka != patient.amka:
                raise ValidationError("Μπορείτε να ακυρώσετε μόνο δικά σας ραντεβού.")
            if not a.is_cancellable(self.now()):
                raise ValidationError(f"Το ραντεβού της {DateUtils.format_date(a.date)} "
                                      f"{DateUtils.format_time(a.time)} δεν μπορεί να ακυρωθεί. Δεν ακυρώθηκε κανένα.")
            to_cancel.append(a)
        for a in to_cancel:
            a.cancel()
            self.appointment_dao.update_status(a.id, a.status)
        return len(to_cancel)

    # ---------- προβολή ----------

    def get_weekly_appointments(self, patient: Patient, any_day_of_week: date) -> list[Appointment]:
        """Τα ραντεβού της εβδομάδας (Δευτέρα–Κυριακή) στην οποία πέφτει η μέρα που δίνουμε."""
        return self.appointment_dao.find_by_patient_and_period(
            patient.amka, DateUtils.start_of_week(any_day_of_week), DateUtils.end_of_week(any_day_of_week))

    def get_monthly_appointments(self, patient: Patient, year: int, month: int) -> list[Appointment]:
        """Όλα τα ραντεβού του μήνα, από την 1η μέχρι την τελευταία του μέρα."""
        return self.appointment_dao.find_by_patient_and_period(
            patient.amka, date(year, month, 1), DateUtils.last_day_of_month(year, month))

    # ---------- βοηθητικά ----------

    def _overlaps_any(self, t: time, booked: list[time]) -> bool:
        return any(self.overlaps(t, b) for b in booked)

    # Εδώ γίνεται όλη η «μαγεία» της διαθεσιμότητας. Για κάθε ώρα του ωραρίου κοιτάμε:
    #   1) αν ο ιατρός έχει ήδη 4 ραντεβού εκείνη τη μέρα (τότε όλα κλειστά),
    #   2) αν πέφτει πάνω σε άλλο ραντεβού (λιγότερο από 1,5 ώρα απόσταση),
    #   3) αν η ώρα έχει ήδη περάσει (για τη σημερινή μέρα).
    # Αν δεν ισχύει τίποτα από αυτά, η ώρα είναι ελεύθερη.
    def _build_slots(self, hours: list[WorkingHours], doctor: Doctor, day: date) -> list[TimeSlot]:
        booked = self.appointment_dao.find_booked_times(doctor.amka, day)
        day_full = len(booked) >= self.MAX_APPOINTMENTS_PER_DAY
        now = self.now()
        slots = []
        for wh in _hours_for(hours, day):
            for t in wh.generate_slot_times():
                available = not day_full and not self._overlaps_any(t, booked) and datetime.combine(day, t) > now
                slots.append(TimeSlot(day, t, available))
        return slots


# Από όλο το ωράριο του ιατρού κρατάει μόνο ό,τι αφορά τη μέρα της εβδομάδας που μας ενδιαφέρει.
def _hours_for(hours: list[WorkingHours], day: date) -> list[WorkingHours]:
    return [wh for wh in hours if wh.day_of_week == day.isoweekday()]
