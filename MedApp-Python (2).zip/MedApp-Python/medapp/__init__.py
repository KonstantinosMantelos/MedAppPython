# Αυτό το αρχείο είναι άδειο επίτηδες. Απλώς λέει στην Python ότι ο φάκελος medapp
# είναι «πακέτο», για να μπορούμε να γράφουμε π.χ. `from medapp.model.doctor import Doctor`.
