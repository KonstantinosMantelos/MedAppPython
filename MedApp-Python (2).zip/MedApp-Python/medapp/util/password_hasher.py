"""Πώς φυλάμε τους κωδικούς χωρίς να τους φυλάμε.

Στη βάση δεν γράφουμε ποτέ τον κωδικό. Γράφουμε ένα hash του με PBKDF2 (έτοιμο στην
Python, στο hashlib) μαζί με ένα τυχαίο «salt». Στη σύνδεση ξανακάνουμε το hash με τον
κωδικό που έδωσε ο χρήστης και κοιτάμε αν βγαίνει το ίδιο. Έτσι, ακόμα κι αν κάποιος
κλέψει το medapp.db, δεν βλέπει κανέναν κωδικό.
"""
import base64
import hashlib
import hmac
import os


class PasswordHasher:
    # Πόσες φορές «ανακατεύεται» ο κωδικός. Όσο περισσότερες, τόσο πιο αργό είναι για κάποιον
    # να δοκιμάζει κωδικούς στα τυφλά. Για εμάς είναι κλάσμα του δευτερολέπτου.
    ITERATIONS = 65_536

    @staticmethod
    # Το salt είναι 16 τυχαία bytes, διαφορετικά για κάθε χρήστη. Έτσι δύο άτομα με τον
    # ίδιο κωδικό έχουν τελείως διαφορετικό hash στη βάση.
    def new_salt() -> str:
        return base64.b64encode(os.urandom(16)).decode("ascii")

    @staticmethod
    def hash(password: str, salt: str) -> str:
        key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), base64.b64decode(salt),
                                  PasswordHasher.ITERATIONS, dklen=32)
        return base64.b64encode(key).decode("ascii")

    @staticmethod
    def verify(password: str, salt: str, expected_hash: str) -> bool:
        # Το compare_digest συγκρίνει πάντα στον ίδιο χρόνο, για να μη «μαρτυράει» τίποτα
        # από το πόσο γρήγορα απάντησε. Μικρή λεπτομέρεια ασφάλειας, αλλά κοστίζει μηδέν.
        return hmac.compare_digest(PasswordHasher.hash(password, salt), expected_hash)
