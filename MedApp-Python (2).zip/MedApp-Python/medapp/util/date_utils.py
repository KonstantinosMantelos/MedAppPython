"""Ό,τι έχει να κάνει με ημερομηνίες: εβδομάδες, μήνες και εμφάνιση στα ελληνικά.

Τα ονόματα των ημερών και των μηνών τα γράψαμε εδώ με το χέρι, αντί να βασιστούμε στις
ρυθμίσεις γλώσσας του υπολογιστή. Αλλιώς σε έναν υπολογιστή στα αγγλικά θα έβγαινε
«Tue» αντί για «Τρί».
"""
import unicodedata
from datetime import date, time, timedelta

DAYS_SHORT = ["Δευ", "Τρί", "Τετ", "Πέμ", "Παρ", "Σάβ", "Κυρ"]
DAYS_FULL = ["Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο", "Κυριακή"]
MONTHS = ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος",
          "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"]


class DateUtils:
    @staticmethod
    # Η εβδομάδα για εμάς είναι Δευτέρα–Κυριακή. Το weekday() δίνει 0 για Δευτέρα,
    # οπότε αν αφαιρέσουμε τόσες μέρες, πέφτουμε πάντα στη Δευτέρα της ίδιας εβδομάδας.
    def start_of_week(any_day: date) -> date:
        return any_day - timedelta(days=any_day.weekday())

    @staticmethod
    def end_of_week(any_day: date) -> date:
        return DateUtils.start_of_week(any_day) + timedelta(days=6)

    @staticmethod
    def format_date(d: date) -> str:
        return d.strftime("%d/%m/%Y")

    @staticmethod
    def format_day_date(d: date) -> str:
        """π.χ. «Τρί 10/11/2026»."""
        return f"{DAYS_SHORT[d.weekday()]} {DateUtils.format_date(d)}"

    @staticmethod
    def format_long(d: date) -> str:
        """π.χ. «Τρίτη 10/11/2026»."""
        return f"{DAYS_FULL[d.weekday()]} {DateUtils.format_date(d)}"

    @staticmethod
    def day_name(d: date) -> str:
        return DAYS_FULL[d.weekday()]

    @staticmethod
    def format_time(t: time) -> str:
        return t.strftime("%H:%M")

    @staticmethod
    def format_month(year: int, month: int) -> str:
        return f"{MONTHS[month - 1]} {year}"

    @staticmethod
    def format_week(any_day: date) -> str:
        return (f"{DateUtils.format_date(DateUtils.start_of_week(any_day))} – "
                f"{DateUtils.format_date(DateUtils.end_of_week(any_day))}")

    @staticmethod
    # Τελευταία μέρα του μήνα: πάμε στην 1η του ΕΠΟΜΕΝΟΥ μήνα και κάνουμε μία μέρα πίσω.
    # Έτσι δεν χρειάζεται να θυμόμαστε ποιος μήνας έχει 30 ή 31 ή τι γίνεται με τα δίσεκτα.
    def last_day_of_month(year: int, month: int) -> date:
        first_next = date(year + (month == 12), month % 12 + 1, 1)
        return first_next - timedelta(days=1)

    @staticmethod
    def greek_sort_key(text: str) -> str:
        """Για να ταξινομούνται σωστά τα ελληνικά. Βγάζουμε τόνους και κεφαλαία, αλλιώς το
        «Ωτορινολαρυγγολόγος» θα έπεφτε σε λάθος θέση και το «Άλλο» πριν από το «Α»."""
        no_accents = "".join(c for c in unicodedata.normalize("NFD", text) if not unicodedata.combining(c))
        return no_accents.lower()
