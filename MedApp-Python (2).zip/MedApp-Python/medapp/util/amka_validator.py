"""Ελέγχει αν ένας ΑΜΚΑ «στέκει».

Ο ΑΜΚΑ έχει 11 ψηφία: τα 6 πρώτα είναι η ημερομηνία γέννησης (ΗΗΜΜΕΕ) και το
τελευταίο είναι ψηφίο ελέγχου με τον αλγόριθμο Luhn (τον ίδιο που έχουν οι κάρτες).
Έτσι πιάνουμε τα περισσότερα λάθη πληκτρολόγησης, π.χ. δύο ψηφία που μπήκαν ανάποδα.
"""
import re


class AmkaValidator:
    @staticmethod
    def is_valid(amka: str | None) -> bool:
        # Πρώτα: ακριβώς 11 ψηφία, τίποτα άλλο (ούτε κενά ούτε γράμματα).
        if amka is None or not re.fullmatch(r"\d{11}", amka):
            return False
        day, month = int(amka[0:2]), int(amka[2:4])
        # Μετά: η μέρα και ο μήνας να είναι λογικοί. Δεν ψάχνουμε αν υπάρχει π.χ. 31 Φεβρουαρίου,
        # αρκεί να πιάνουμε τα χοντρά λάθη.
        if not (1 <= day <= 31 and 1 <= month <= 12):
            return False
        return AmkaValidator.luhn(amka)

    @staticmethod
    def luhn(digits: str) -> bool:
        # Luhn σε δύο λόγια: ξεκινάμε από το τέλος, διπλασιάζουμε κάθε δεύτερο ψηφίο
        # (αν βγει διψήφιο, αφαιρούμε 9), τα προσθέτουμε όλα, και το σύνολο πρέπει να
        # διαιρείται ακριβώς με το 10.
        total = 0
        for i, ch in enumerate(reversed(digits)):
            d = int(ch)
            if i % 2 == 1:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
        return total % 10 == 0
