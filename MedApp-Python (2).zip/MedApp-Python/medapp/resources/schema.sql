-- Οι πίνακες της βάσης. Τρέχει σε κάθε εκκίνηση, αλλά το IF NOT EXISTS κάνει να φτιάχνονται
-- μόνο την πρώτη φορά. Αν ο πίνακας υπάρχει ήδη, δεν τον αγγίζει.
--
-- Μικρή σημείωση: η SQLite δεν έχει τύπους ημερομηνίας/ώρας, οπότε τις κρατάμε ως κείμενο
-- ("2026-11-11", "09:00"). Σε αυτή τη μορφή ταξινομούνται και συγκρίνονται σωστά.

-- Οι ιατροί, με ό,τι ζητάει η εκφώνηση. Ο ΑΜΚΑ είναι το κλειδί (11 χαρακτήρες ακριβώς).
CREATE TABLE IF NOT EXISTS doctors (
    amka        TEXT PRIMARY KEY CHECK (length(amka) = 11),
    first_name  TEXT NOT NULL,
    last_name   TEXT NOT NULL,
    specialty   TEXT NOT NULL,
    phone       TEXT NOT NULL,
    email       TEXT NOT NULL,
    area        TEXT NOT NULL,
    address     TEXT NOT NULL
);

-- Το ωράριο: μία γραμμή για κάθε μέρα που δουλεύει ένας ιατρός. Αν σβηστεί ο ιατρός,
-- σβήνεται και το ωράριό του (ON DELETE CASCADE).
CREATE TABLE IF NOT EXISTS working_hours (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_amka  TEXT NOT NULL REFERENCES doctors(amka) ON DELETE CASCADE,
    day_of_week  INTEGER NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    start_time   TEXT NOT NULL,
    end_time     TEXT NOT NULL,
    slot_minutes INTEGER NOT NULL DEFAULT 30 CHECK (slot_minutes > 0)
);

-- Οι ασθενείς. Προσοχή: κωδικός δεν αποθηκεύεται, μόνο hash + salt (δες password_hasher.py).
CREATE TABLE IF NOT EXISTS patients (
    amka          TEXT PRIMARY KEY CHECK (length(amka) = 11),
    first_name    TEXT NOT NULL,
    last_name     TEXT NOT NULL,
    phone         TEXT,
    email         TEXT,
    password_hash TEXT NOT NULL,
    salt          TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

-- Τα ραντεβού. Το status είναι ACTIVE ή CANCELLED· τα ακυρωμένα δεν σβήνονται, μένουν για ιστορικό.
CREATE TABLE IF NOT EXISTS appointments (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_amka  TEXT NOT NULL REFERENCES patients(amka),
    doctor_amka   TEXT NOT NULL REFERENCES doctors(amka),
    appt_date     TEXT NOT NULL,
    appt_time     TEXT NOT NULL,
    reason        TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'CANCELLED')),
    created_at    TEXT NOT NULL
);

-- Δίχτυ ασφαλείας στο επίπεδο της βάσης: ακόμα κι αν κάτι ξεφύγει από τον κώδικα, η βάση
-- δεν δέχεται δύο ΕΝΕΡΓΑ ραντεβού στον ίδιο ιατρό την ίδια ώρα. Το WHERE status = 'ACTIVE'
-- (μερικό ευρετήριο) αφήνει να ξανακλειστεί μια ώρα που είχε ακυρωθεί.
CREATE UNIQUE INDEX IF NOT EXISTS ux_doctor_slot
    ON appointments(doctor_amka, appt_date, appt_time) WHERE status = 'ACTIVE';

-- Το ίδιο για τον ασθενή: όχι δύο ενεργά ραντεβού την ίδια ώρα.
CREATE UNIQUE INDEX IF NOT EXISTS ux_patient_slot
    ON appointments(patient_amka, appt_date, appt_time) WHERE status = 'ACTIVE';

-- Δύο απλά ευρετήρια για να είναι γρήγορες οι αναζητήσεις που κάνουμε συνέχεια.
CREATE INDEX IF NOT EXISTS ix_doctor_search ON doctors(specialty, area);
CREATE INDEX IF NOT EXISTS ix_appt_patient_date ON appointments(patient_amka, appt_date);

-- Οι 3 προκαθορισμένοι λόγοι επίσκεψης κάθε ιατρού (ο ασθενής μπορεί να διαλέξει και «Άλλο»)
CREATE TABLE IF NOT EXISTS visit_reasons (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_amka  TEXT NOT NULL REFERENCES doctors(amka) ON DELETE CASCADE,
    reason       TEXT NOT NULL,
    sort_order   INTEGER NOT NULL,
    UNIQUE (doctor_amka, reason)
);
