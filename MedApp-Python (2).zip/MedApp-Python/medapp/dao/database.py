"""Η σύνδεση με τη βάση SQLite.

Η SQLite είναι απλώς ένα αρχείο (medapp.db) και η Python έχει έτοιμη τη βιβλιοθήκη sqlite3,
οπότε δεν στήνουμε κανέναν server. Εδώ ανοίγουμε συνδέσεις και τρέχουμε τα αρχεία .sql
που φτιάχνουν τους πίνακες και βάζουν τους ιατρούς.
"""
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

RESOURCES = Path(__file__).resolve().parent.parent / "resources"


class DataAccessError(Exception):
    """Δικό μας σφάλμα για όταν κάτι στραβώσει με τη βάση. Τυλίγουμε μέσα το sqlite3.Error,
    για να μη χρειάζεται τα άλλα επίπεδα να ξέρουν ότι από κάτω είναι SQLite."""


class Database:
    def __init__(self, file_name: str):
        self.file_name = file_name

    def get_connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.file_name)
        # Με το Row διαβάζουμε στήλες με το όνομά τους, row["amka"], αντί για row[0].
        connection.row_factory = sqlite3.Row
        # Η SQLite, για ιστορικούς λόγους, ΔΕΝ ελέγχει τα foreign keys αν δεν της το πεις
        # σε κάθε σύνδεση. Αυτή η γραμμή το ανοίγει.
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Αυτό χρησιμοποιούν όλα τα DAO με `with self.db.connect() as c:`.
        Αν όλα πάνε καλά κάνει commit, αν πεταχτεί σφάλμα κάνει rollback, και στο τέλος
        κλείνει πάντα τη σύνδεση. Έτσι δεν ξεχνάμε ποτέ ανοιχτές συνδέσεις."""
        connection = self.get_connection()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        """Τρέχει σε κάθε εκκίνηση: φτιάχνει τους πίνακες (αν δεν υπάρχουν) και βάζει
        ιατρούς, ωράρια και λόγους επίσκεψης.

        Τα .sql είναι γραμμένα ώστε να μπορούν να ξανατρέξουν άφοβα (INSERT OR IGNORE κ.λπ.),
        οπότε δεν διπλασιάζονται οι ιατροί και δεν χάνονται τα ραντεβού που έχεις ήδη κλείσει.
        """
        for script in ("schema.sql", "data.sql", "visit_reasons.sql"):
            self._run_script(script)

    def _run_script(self, name: str) -> None:
        sql = (RESOURCES / name).read_text(encoding="utf-8")
        try:
            connection = self.get_connection()
            try:
                # Όλο το αρχείο σε μία συναλλαγή: ή περνάει ολόκληρο ή τίποτα.
                connection.executescript("BEGIN;\n" + sql + "\nCOMMIT;")
            finally:
                connection.close()
        except sqlite3.Error as e:
            raise DataAccessError(f"Αποτυχία εκτέλεσης {name}: {e}") from e
