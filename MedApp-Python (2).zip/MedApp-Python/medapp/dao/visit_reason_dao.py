"""Φέρνει τους 3 έτοιμους λόγους επίσκεψης κάθε ιατρού (π.χ. «Μέτρηση όρασης / γυαλιά»).
Το «Άλλο» δεν είναι στη βάση. Το προσθέτει το DoctorService στο τέλος της λίστας."""
import sqlite3

from medapp.dao.database import Database, DataAccessError


class VisitReasonDAO:
    SQL_BY_DOCTOR = "SELECT reason FROM visit_reasons WHERE doctor_amka = ? ORDER BY sort_order"

    def __init__(self, db: Database):
        self.db = db

    def find_by_doctor(self, doctor_amka: str) -> list[str]:
        try:
            with self.db.connect() as c:
                return [r[0] for r in c.execute(self.SQL_BY_DOCTOR, (doctor_amka,))]
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης λόγων επίσκεψης") from e
