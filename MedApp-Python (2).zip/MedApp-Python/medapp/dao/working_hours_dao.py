"""Φέρνει το ωράριο ενός ιατρού (ποιες μέρες δουλεύει και τι ώρες)."""
import sqlite3
from datetime import time

from medapp.dao.database import Database, DataAccessError
from medapp.model.working_hours import WorkingHours


class WorkingHoursDAO:
    SQL_BY_DOCTOR = "SELECT * FROM working_hours WHERE doctor_amka = ? ORDER BY day_of_week, start_time"

    def __init__(self, db: Database):
        self.db = db

    def find_by_doctor(self, doctor_amka: str) -> list[WorkingHours]:
        try:
            with self.db.connect() as c:
                # Οι ώρες είναι αποθηκευμένες ως κείμενο "09:00", οπότε τις κάνουμε time.
                return [WorkingHours(r["doctor_amka"], r["day_of_week"], time.fromisoformat(r["start_time"]),
                                     time.fromisoformat(r["end_time"]), r["slot_minutes"])
                        for r in c.execute(self.SQL_BY_DOCTOR, (doctor_amka,))]
        except sqlite3.Error as e:
            raise DataAccessError("Αποτυχία ανάγνωσης ωραρίου") from e
