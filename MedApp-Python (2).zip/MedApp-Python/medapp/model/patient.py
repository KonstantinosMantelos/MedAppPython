"""Ο ασθενής, δηλαδή ο χρήστης της εφαρμογής. Ο ΑΜΚΑ του είναι και το «username» του."""
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Patient:
    amka: str
    first_name: str
    last_name: str
    phone: str
    email: str
    # Προσοχή: ΔΕΝ κρατάμε ποτέ τον κωδικό όπως τον έγραψε ο χρήστης. Κρατάμε μόνο ένα
    # «hash» του (κάτι σαν δακτυλικό αποτύπωμα) και το salt με το οποίο φτιάχτηκε.
    # Δες το util/password_hasher.py για το πώς γίνεται.
    password_hash: str
    salt: str
    created_at: datetime

    # Εδώ πρώτα το όνομα και μετά το επώνυμο, γιατί το δείχνουμε στο «Καλώς ήρθατε, ...».
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    def __str__(self) -> str:
        return f"{self.full_name} [{self.amka}]"
