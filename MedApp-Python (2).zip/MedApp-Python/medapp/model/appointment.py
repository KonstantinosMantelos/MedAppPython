"""Ένα ραντεβού: ποιος ασθενής, με ποιον ιατρό, πότε και γιατί."""
from dataclasses import dataclass
from datetime import date, datetime, time

from medapp.model.appointment_status import AppointmentStatus
from medapp.model.doctor import Doctor


# Εδώ ΔΕΝ βάζουμε frozen=True, γιατί δύο πράγματα αλλάζουν μετά τη δημιουργία:
# το id (το δίνει η βάση όταν το αποθηκεύσουμε) και το status (όταν ακυρωθεί).
@dataclass
class Appointment:
    id: int
    patient_amka: str
    doctor: Doctor
    date: date
    time: time
    reason: str
    status: AppointmentStatus
    created_at: datetime

    # Ημερομηνία + ώρα μαζί, για να συγκρίνουμε εύκολα με το «τώρα».
    @property
    def date_time(self) -> datetime:
        return datetime.combine(self.date, self.time)

    def cancel(self) -> None:
        """Ακυρώνει το ραντεβού. Αν δεν είναι ενεργό (π.χ. είναι ήδη ακυρωμένο), πετάει σφάλμα,
        για να μην μπορεί ποτέ να γίνει κάτι παράλογο όπως «ακύρωση ακυρωμένου»."""
        if self.status != AppointmentStatus.ACTIVE:
            raise ValueError("Μόνο ενεργό ραντεβού μπορεί να ακυρωθεί.")
        self.status = AppointmentStatus.CANCELLED

    def get_effective_status(self, now: datetime) -> AppointmentStatus:
        """Τι κατάσταση να δείξουμε στον χρήστη. Το now το περνάμε απ' έξω (αντί να
        καλούμε μέσα datetime.now()), για να μπορούν τα tests να «παγώνουν» την ώρα."""
        if self.status == AppointmentStatus.ACTIVE and self.date_time <= now:
            return AppointmentStatus.COMPLETED
        return self.status

    def is_cancellable(self, now: datetime) -> bool:
        """Ακυρώνεται μόνο αν είναι ενεργό ΚΑΙ δεν έχει έρθει ακόμα η ώρα του.
        Ένα ραντεβού που πέρασε δεν έχει νόημα να το ακυρώσεις."""
        return self.get_effective_status(now) == AppointmentStatus.ACTIVE
