"""Ο ιατρός. Κρατάμε μόνο όσα ζητάει η εκφώνηση: ΑΜΚΑ, όνομα, ειδικότητα,
στοιχεία επικοινωνίας και πού είναι το ιατρείο του."""
from dataclasses import dataclass


# Το @dataclass μας γλιτώνει από το να γράφουμε __init__ με το χέρι: φτιάχνει μόνο του
# τον constructor από τα πεδία που δηλώνουμε από κάτω. Το frozen=True σημαίνει ότι
# μόλις φτιαχτεί ένας ιατρός δεν αλλάζει (δεν χρειάζεται να αλλάζει μέσα στην εφαρμογή).
@dataclass(frozen=True)
class Doctor:
    amka: str
    first_name: str
    last_name: str
    specialty: str
    phone: str
    email: str
    area: str
    address: str

    # Το @property κάνει τη μέθοδο να διαβάζεται σαν πεδίο: γράφουμε doctor.full_name
    # χωρίς παρενθέσεις. Βάζουμε πρώτα το επώνυμο, όπως στις λίστες ιατρών.
    @property
    def full_name(self) -> str:
        return f"{self.last_name} {self.first_name}"

    @property
    def contact_info(self) -> str:
        """Τηλέφωνο και email μαζί σε μία γραμμή, για να τα δείχνουμε στο παράθυρο κράτησης."""
        return f"{self.phone} · {self.email}"

    # Αυτό καλείται όταν κάνουμε print(doctor). Βολεύει πολύ στο debugging.
    def __str__(self) -> str:
        return f"{self.full_name} ({self.specialty}, {self.area})"
