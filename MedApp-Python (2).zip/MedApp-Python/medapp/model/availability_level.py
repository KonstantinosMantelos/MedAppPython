"""Πόσο «ελεύθερος» είναι ένας ιατρός μια συγκεκριμένη μέρα.

Κάθε ιατρός έχει 4 ραντεβού τη μέρα, οπότε το χρώμα βγαίνει απλά από το πόσα έμειναν
ελεύθερα. Ο υπολογισμός γίνεται στο AppointmentService.classify().
"""
from enum import Enum


class AvailabilityLevel(Enum):
    AVAILABLE = "Διαθεσιμότητα"          # 3–4 ελεύθερα ραντεβού (πράσινο)
    PARTIAL = "Μερική διαθεσιμότητα"     # 1–2 ελεύθερα ραντεβού (κίτρινο)
    NONE = "Μη διαθέσιμο"                # κανένα ελεύθερο ραντεβού (κόκκινο)

    @property
    def label(self) -> str:
        return self.value

    def __str__(self) -> str:
        return self.value
