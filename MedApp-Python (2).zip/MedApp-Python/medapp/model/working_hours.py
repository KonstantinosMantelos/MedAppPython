"""Το ωράριο ενός ιατρού για μία μέρα της εβδομάδας (π.χ. «Τετάρτη 09:00–15:00, ανά 90 λεπτά»).
Αν ένας ιατρός δουλεύει 3 μέρες, έχει 3 τέτοιες γραμμές στη βάση."""
from dataclasses import dataclass
from datetime import datetime, time, timedelta


@dataclass(frozen=True)
class WorkingHours:
    doctor_amka: str
    day_of_week: int          # 1 = Δευτέρα ... 7 = Κυριακή, ίδιο με το date.isoweekday() της Python
    start_time: time
    end_time: time
    slot_minutes: int

    def generate_slot_times(self) -> list[time]:
        """Σπάει το ωράριο σε ώρες έναρξης ραντεβού. Για 09:00–15:00 ανά 90 λεπτά
        βγάζει 09:00, 10:30, 12:00, 13:30 (το 15:00 δεν χωράει, γιατί θα τελείωνε 16:30)."""
        # Το time της Python δεν ξέρει να προσθέτει λεπτά, οπότε το κολλάμε σε μια τυχαία
        # ημερομηνία (2000-01-01), κάνουμε την πρόσθεση και μετά κρατάμε μόνο την ώρα.
        day = datetime(2000, 1, 1)
        t = datetime.combine(day, self.start_time)
        end = datetime.combine(day, self.end_time)
        step = timedelta(minutes=self.slot_minutes)
        times = []
        # Συνεχίζουμε όσο το ραντεβού προλαβαίνει να ΤΕΛΕΙΩΣΕΙ μέσα στο ωράριο.
        while t + step <= end:
            times.append(t.time())
            t += step
        return times
