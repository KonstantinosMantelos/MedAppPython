"""Μια «θέση» στο πρόγραμμα του ιατρού: συγκεκριμένη μέρα και ώρα, και αν είναι ελεύθερη.

Αυτά δεν τα αποθηκεύουμε πουθενά. Τα φτιάχνουμε κάθε φορά από το ωράριο, αφαιρώντας
όσα έχουν ήδη κλειστεί (δες AppointmentService._build_slots).
"""
from dataclasses import dataclass
from datetime import date, time


@dataclass(frozen=True)
class TimeSlot:
    date: date
    time: time
    available: bool

    def __str__(self) -> str:
        return self.time.strftime("%H:%M") + ("" if self.available else " (κλεισμένο)")
