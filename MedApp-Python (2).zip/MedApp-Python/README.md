# MedApp (Python) – Ραντεβού ασθενών με ιατρούς (Ομάδα 9)

Η ίδια εφαρμογή με την έκδοση Java, γραμμένη σε **Python 3 + Tkinter + SQLite**.
Δεν χρειάζεται καμία εξωτερική βιβλιοθήκη: το Tkinter και το sqlite3 περιλαμβάνονται στην Python.

## Λειτουργίες
- Εγγραφή ασθενή με ΑΜΚΑ (έλεγχος εγκυρότητας) και κωδικό· σύνδεση.
- 90 φανταστικοί ιατροί: 15 ειδικότητες × 6 περιοχές της Αθήνας (ΑΜΚΑ, ονοματεπώνυμο, ειδικότητα,
  τηλέφωνο, email, περιοχή, διεύθυνση).
- Αναζήτηση: ειδικότητα, μία ή περισσότερες περιοχές μαζί, ημερομηνία από ημερολόγιο.
  Εμφανίζονται οι ιατροί που δέχονται εκείνη την ημέρα με τις ελεύθερες ώρες τους και χρώμα:
  πράσινο 3–4 ελεύθερα, κίτρινο 1–2, κόκκινο κανένα (με το επόμενο ελεύθερο ραντεβού).
- Κράτηση: ημέρα, ώρα και λόγος επίσκεψης (3 λόγοι ανά ιατρό ή «Άλλο» με ελεύθερο κείμενο).
- Ακύρωση ενός ραντεβού ή πολλών μαζί («Επιλογή πολλών για ακύρωση», όλα ή κανένα).
- Προβολή των ραντεβού ανά εβδομάδα και ανά μήνα.

## Κανόνες ραντεβού
- Ωράριο ιατρείου 09:00–15:00 με 4 ραντεβού του 1,5 ώρας: 09:00, 10:30, 12:00, 13:30.
- Έως 4 ραντεβού ανά ιατρό την ημέρα· δύο ραντεβού του ίδιου ιατρού ή ασθενή απέχουν ≥ 1,5 ώρα.
- Ραντεβού μόνο σε μελλοντική ώρα και έως 30 ημέρες μπροστά.

## Απαιτήσεις
- **Python 3.10 ή νεότερη** (python.org). Στα Windows και στο macOS ο εγκαταστάτης του python.org
  περιέχει ήδη το Tkinter (στα Windows να μείνει τσεκαρισμένο το «tcl/tk and IDLE» και καλό είναι
  και το «Add python.exe to PATH»). Σε Linux: `sudo apt install python3-tk`.

## Εκτέλεση
```
cd C:\MedApp-Python
python app.py
```
Δοκιμαστικός λογαριασμός: **ΑΜΚΑ 01019000015 – κωδικός demo123**.
Για νέα εγγραφή χρειάζεται έγκυρος ΑΜΚΑ (ψηφίο ελέγχου Luhn), π.χ. `15059501237`.
Η βάση `medapp.db` δημιουργείται δίπλα στο `app.py`· για καθαρή εκκίνηση διαγράψτε την.

Σε IDE (PyCharm, VS Code): ανοίξτε τον φάκελο `MedApp-Python` και τρέξτε το `app.py`.

## Έλεγχοι
```
python -m unittest -v
```
16 έλεγχοι με πραγματική προσωρινή βάση SQLite (εγγραφή, σύνδεση, αναζήτηση σε πολλές περιοχές,
4 ραντεβού την ημέρα, χρώματα διαθεσιμότητας, κράτηση, λόγος «Άλλο», ακύρωση, μαζική ακύρωση,
εβδομάδα/μήνας).

## Δομή
| Φάκελος | Περιεχόμενο |
| --- | --- |
| `app.py` | Σημείο εκκίνησης |
| `medapp/model` | Doctor, Patient, Appointment, AppointmentStatus, AvailabilityLevel, WorkingHours, TimeSlot |
| `medapp/dao` | Database, PatientDAO, DoctorDAO, WorkingHoursDAO, AppointmentDAO, VisitReasonDAO |
| `medapp/service` | AuthService, DoctorService, AppointmentService, ValidationError |
| `medapp/ui` | Οθόνες Tkinter (MainFrame, LoginPanel, RegisterPanel, PatientHomePanel, SearchDoctorPanel, BookingDialog, MyAppointmentsPanel, DatePicker) και θέμα εμφάνισης |
| `medapp/util` | AmkaValidator, PasswordHasher, DateUtils |
| `medapp/resources` | schema.sql, data.sql (90 ιατροί + ωράρια), visit_reasons.sql — ίδια με την έκδοση Java |
| `tests` | Έλεγχοι unittest |
| `uml` | Τα 9 διαγράμματα UML σε PlantUML, με τα ονόματα της Python |

## Αντιστοιχία με την έκδοση Java
Ίδιες κλάσεις, ίδιοι κανόνες, ίδια βάση. Οι μέθοδοι ακολουθούν το στυλ της Python (PEP 8):
`findDoctors` → `find_doctors`, `getAvailableSlots` → `get_available_slots`, `cancelAll` → `cancel_all`,
`ValidationException` → `ValidationError` κ.λπ. Τα διαγράμματα στον φάκελο `uml` χρησιμοποιούν αυτά τα ονόματα.

## Διαγράμματα UML και CASE tool
- `uml/01`–`09 *.puml`: τα 9 διαγράμματα σε PlantUML (ανοίγουν στο plantuml.com ή με πρόσθετο PlantUML).
- `uml/images`: τα 9 διαγράμματα ως έτοιμες εικόνες PNG.
- `uml/argouml/MedApp.xmi`: το μοντέλο UML για το **ArgoUML** (File → Import XMI): όλες οι κλάσεις με πεδία,
  μεθόδους και σχέσεις, ο χειριστής και οι περιπτώσεις χρήσης. Οδηγίες βήμα-βήμα: `uml/argouml/ΟΔΗΓΙΕΣ.md`.
